"use client";

import { useEffect, useRef, useState } from "react";
import { BookMarked, Plus, Check, Loader2, X } from "lucide-react";
import type { NotebookSummary } from "@/lib/types";

export interface QuestionPayload {
  questionText: string;
  options: string[];
  correctIndex: number;
  selectedIndex: number | null;
  explanation: string | null;
  sourceTestId?: number | null;
  sourceTestTitle?: string | null;
}

const NB_COLORS = ["#ef4444", "#f59e0b", "#6366f1", "#10b981", "#ec4899", "#06b6d4"];
const NB_ICONS = ["📕", "📓", "📔", "⚠️", "🔥", "🎯"];

export function AddToNotebook({ question }: { question: QuestionPayload }) {
  const [open, setOpen] = useState(false);
  const [notebooks, setNotebooks] = useState<NotebookSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [busyId, setBusyId] = useState<number | "new" | null>(null);
  const [savedTo, setSavedTo] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [newName, setNewName] = useState("");
  const [newColor, setNewColor] = useState(NB_COLORS[0]);
  const [newIcon, setNewIcon] = useState(NB_ICONS[0]);
  const ref = useRef<HTMLDivElement>(null);

  const loadNotebooks = () => {
    setLoading(true);
    fetch("/api/notebooks")
      .then((r) => r.json())
      .then((d) => setNotebooks(Array.isArray(d) ? d : []))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    if (open) loadNotebooks();
  }, [open]);

  // Close on outside click.
  useEffect(() => {
    if (!open) return;
    const onClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
        setCreating(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open]);

  const addToNotebook = async (notebookId: number, name: string) => {
    setBusyId(notebookId);
    const res = await fetch("/api/notebook-entries", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ notebookId, ...question }),
    });
    setBusyId(null);
    if (res.ok) {
      setSavedTo(name);
      setTimeout(() => {
        setOpen(false);
        setCreating(false);
      }, 900);
    }
  };

  const createAndAdd = async () => {
    if (!newName.trim()) return;
    setBusyId("new");
    const res = await fetch("/api/notebooks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newName.trim(), color: newColor, icon: newIcon }),
    });
    const nb = await res.json();
    if (res.ok && nb.id) {
      await addToNotebook(nb.id, nb.name);
      setNewName("");
    } else {
      setBusyId(null);
    }
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors"
        style={{
          background: savedTo ? "var(--success-light)" : "var(--bg-hover)",
          color: savedTo ? "var(--success)" : "var(--text-secondary)",
        }}
      >
        {savedTo ? <Check size={13} /> : <BookMarked size={13} />}
        {savedTo ? `Saved to ${savedTo}` : "Add to Mistakes Notebook"}
      </button>

      {open && (
        <div
          className="surface animate-scale-in absolute right-0 z-50 mt-2 w-64 rounded-xl p-3 shadow-lg"
          style={{ boxShadow: "var(--shadow-lg)" }}
        >
          <div className="mb-2 flex items-center justify-between">
            <span className="text-xs font-semibold" style={{ color: "var(--text-muted)" }}>
              {creating ? "New Notebook" : "Choose a notebook"}
            </span>
            <button
              onClick={() => {
                setOpen(false);
                setCreating(false);
              }}
              className="grid h-6 w-6 place-items-center rounded"
              style={{ color: "var(--text-muted)" }}
            >
              <X size={13} />
            </button>
          </div>

          {creating ? (
            <div className="space-y-3">
              <input
                autoFocus
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="Notebook name"
                className="w-full rounded-lg border px-3 py-2 text-sm"
                style={{
                  borderColor: "var(--border-color)",
                  background: "var(--bg-primary)",
                  color: "var(--text-primary)",
                }}
                onKeyDown={(e) => e.key === "Enter" && createAndAdd()}
              />
              <div className="flex gap-1.5">
                {NB_ICONS.map((ic) => (
                  <button
                    key={ic}
                    onClick={() => setNewIcon(ic)}
                    className="grid h-7 w-7 place-items-center rounded-md text-sm"
                    style={{
                      background: newIcon === ic ? "var(--accent-light)" : "var(--bg-hover)",
                      outline: newIcon === ic ? "1.5px solid var(--accent)" : "none",
                    }}
                  >
                    {ic}
                  </button>
                ))}
              </div>
              <div className="flex gap-1.5">
                {NB_COLORS.map((c) => (
                  <button
                    key={c}
                    onClick={() => setNewColor(c)}
                    className="h-6 w-6 rounded-full"
                    style={{
                      background: c,
                      outline: newColor === c ? "2px solid var(--text-primary)" : "none",
                      outlineOffset: 1,
                    }}
                  />
                ))}
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setCreating(false)}
                  className="flex-1 rounded-lg py-2 text-xs font-medium"
                  style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
                >
                  Back
                </button>
                <button
                  onClick={createAndAdd}
                  disabled={!newName.trim() || busyId === "new"}
                  className="btn-primary flex-1 py-2 text-xs disabled:opacity-50"
                >
                  {busyId === "new" ? (
                    <Loader2 size={13} className="mx-auto animate-spin" />
                  ) : (
                    "Create & Save"
                  )}
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="max-h-48 space-y-1 overflow-y-auto">
                {loading ? (
                  <div className="py-4 text-center">
                    <Loader2 size={16} className="mx-auto animate-spin" style={{ color: "var(--accent)" }} />
                  </div>
                ) : notebooks.length === 0 ? (
                  <p className="py-3 text-center text-xs" style={{ color: "var(--text-muted)" }}>
                    No notebooks yet. Create one below.
                  </p>
                ) : (
                  notebooks.map((nb) => (
                    <button
                      key={nb.id}
                      onClick={() => addToNotebook(nb.id, nb.name)}
                      disabled={busyId === nb.id}
                      className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-sm transition-colors hover:bg-[var(--bg-hover)]"
                    >
                      <span
                        className="grid h-7 w-7 shrink-0 place-items-center rounded-md text-sm"
                        style={{ background: nb.color + "22" }}
                      >
                        {nb.icon}
                      </span>
                      <span className="min-w-0 flex-1 truncate">{nb.name}</span>
                      {busyId === nb.id ? (
                        <Loader2 size={14} className="animate-spin" style={{ color: "var(--accent)" }} />
                      ) : (
                        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                          {nb.entryCount}
                        </span>
                      )}
                    </button>
                  ))
                )}
              </div>
              <button
                onClick={() => setCreating(true)}
                className="mt-2 flex w-full items-center justify-center gap-1.5 rounded-lg border border-dashed py-2 text-xs font-medium"
                style={{ borderColor: "var(--border-color)", color: "var(--accent)" }}
              >
                <Plus size={13} /> New Notebook
              </button>
            </>
          )}
        </div>
      )}
    </div>
  );
}
