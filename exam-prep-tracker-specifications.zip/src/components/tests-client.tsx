"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Plus,
  Pencil,
  Trash2,
  X,
  ClipboardList,
  Clock,
  Play,
  Trophy,
  Check,
  GripVertical,
} from "lucide-react";
import type { TestSummary, Subject, FullQuestion } from "@/lib/types";

interface QForm {
  questionText: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

interface TestForm {
  id?: number;
  title: string;
  description: string;
  subjectId: string;
  durationMinutes: number;
  marksPerQuestion: number;
  negativeMarks: number;
  questions: QForm[];
}

function blankQuestion(): QForm {
  return { questionText: "", options: ["", ""], correctIndex: 0, explanation: "" };
}

const EMPTY: TestForm = {
  title: "",
  description: "",
  subjectId: "",
  durationMinutes: 30,
  marksPerQuestion: 1,
  negativeMarks: 0,
  questions: [blankQuestion()],
};

export function TestsClient() {
  const [tests, setTests] = useState<TestSummary[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<TestForm>(EMPTY);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const load = () => {
    Promise.all([
      fetch("/api/tests").then((r) => r.json()),
      fetch("/api/subjects").then((r) => r.json()),
    ])
      .then(([t, s]) => {
        setTests(Array.isArray(t) ? t : []);
        setSubjects(Array.isArray(s) ? s : []);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const openCreate = () => {
    setForm({ ...EMPTY, questions: [blankQuestion()] });
    setErr(null);
    setModalOpen(true);
  };

  const openEdit = async (id: number) => {
    setErr(null);
    const res = await fetch(`/api/tests/${id}?withAnswers=1`);
    const data = await res.json();
    setForm({
      id: data.id,
      title: data.title,
      description: data.description ?? "",
      subjectId: data.subjectId ? String(data.subjectId) : "",
      durationMinutes: data.durationMinutes,
      marksPerQuestion: data.marksPerQuestion,
      negativeMarks: data.negativeMarks,
      questions: (data.questions as FullQuestion[]).map((q) => ({
        questionText: q.questionText,
        options: q.options,
        correctIndex: q.correctIndex,
        explanation: q.explanation ?? "",
      })),
    });
    setModalOpen(true);
  };

  const save = async () => {
    setErr(null);
    if (!form.title.trim()) {
      setErr("Please enter a test title.");
      return;
    }
    const cleaned = form.questions
      .map((q) => ({
        ...q,
        options: q.options.map((o) => o.trim()),
      }))
      .filter((q) => q.questionText.trim() && q.options.filter(Boolean).length >= 2);
    if (cleaned.length === 0) {
      setErr("Add at least one question with a prompt and 2+ filled options.");
      return;
    }
    setSaving(true);
    const payload = {
      ...form,
      questions: cleaned.map((q) => {
        const filled = q.options.filter(Boolean);
        // Re-map correctIndex if empty options were removed.
        const correctVal = q.options[q.correctIndex];
        const newIndex = Math.max(0, filled.indexOf(correctVal));
        return {
          questionText: q.questionText,
          options: filled,
          correctIndex: newIndex,
          explanation: q.explanation,
        };
      }),
    };
    const res = await fetch(form.id ? `/api/tests/${form.id}` : "/api/tests", {
      method: form.id ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setSaving(false);
    if (!res.ok) {
      const d = await res.json();
      setErr(d.error || "Failed to save test.");
      return;
    }
    setModalOpen(false);
    setLoading(true);
    load();
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this test and all its attempts?")) return;
    await fetch(`/api/tests?id=${id}`, { method: "DELETE" });
    setTests((prev) => prev.filter((t) => t.id !== id));
  };

  // --- question builder helpers ---
  const updateQ = (idx: number, patch: Partial<QForm>) =>
    setForm((f) => ({
      ...f,
      questions: f.questions.map((q, i) => (i === idx ? { ...q, ...patch } : q)),
    }));

  const addQuestion = () =>
    setForm((f) => ({ ...f, questions: [...f.questions, blankQuestion()] }));

  const removeQuestion = (idx: number) =>
    setForm((f) => ({
      ...f,
      questions: f.questions.filter((_, i) => i !== idx),
    }));

  const addOption = (qi: number) =>
    setForm((f) => ({
      ...f,
      questions: f.questions.map((q, i) =>
        i === qi && q.options.length < 6
          ? { ...q, options: [...q.options, ""] }
          : q
      ),
    }));

  const removeOption = (qi: number, oi: number) =>
    setForm((f) => ({
      ...f,
      questions: f.questions.map((q, i) => {
        if (i !== qi || q.options.length <= 2) return q;
        const options = q.options.filter((_, k) => k !== oi);
        let correctIndex = q.correctIndex;
        if (oi === q.correctIndex) correctIndex = 0;
        else if (oi < q.correctIndex) correctIndex -= 1;
        return { ...q, options, correctIndex };
      }),
    }));

  const setOption = (qi: number, oi: number, val: string) =>
    setForm((f) => ({
      ...f,
      questions: f.questions.map((q, i) =>
        i === qi
          ? { ...q, options: q.options.map((o, k) => (k === oi ? val : o)) }
          : q
      ),
    }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Mock Tests</h1>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Build timed tests, attempt them, and review your score.
          </p>
        </div>
        <button
          onClick={openCreate}
          className="btn-primary flex items-center gap-2 px-5 py-3 text-sm"
        >
          <Plus size={17} /> Create Test
        </button>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-44 rounded-2xl" />
          ))}
        </div>
      ) : tests.length === 0 ? (
        <div className="surface flex flex-col items-center gap-3 rounded-2xl py-16 text-center">
          <div
            className="grid h-14 w-14 place-items-center rounded-2xl"
            style={{ background: "var(--accent-light)", color: "var(--accent)" }}
          >
            <ClipboardList size={26} />
          </div>
          <p className="text-lg font-semibold">No tests yet</p>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            Create your first mock test — add questions and the answer key.
          </p>
          <button
            onClick={openCreate}
            className="btn-primary mt-2 flex items-center gap-2 px-5 py-2.5 text-sm"
          >
            <Plus size={16} /> Create Test
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {tests.map((t, i) => (
            <div
              key={t.id}
              className={`surface card-hover animate-slide-up flex flex-col rounded-2xl p-5 stagger-${(i % 5) + 1}`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="truncate font-semibold">{t.title}</h3>
                  <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                    {t.subjectName ?? "General"}
                  </p>
                </div>
                {t.bestScore !== null && (
                  <span
                    className="flex shrink-0 items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold"
                    style={{ background: "var(--warning-light)", color: "var(--warning)" }}
                  >
                    <Trophy size={12} /> {t.bestScore}
                  </span>
                )}
              </div>

              <div
                className="mt-4 flex flex-wrap gap-3 text-xs"
                style={{ color: "var(--text-secondary)" }}
              >
                <span className="flex items-center gap-1">
                  <ClipboardList size={13} /> {t.questionCount} Qs
                </span>
                <span className="flex items-center gap-1">
                  <Clock size={13} /> {t.durationMinutes} min
                </span>
                <span className="flex items-center gap-1">
                  <Play size={13} /> {t.attemptCount} attempts
                </span>
              </div>

              <div className="mt-5 flex gap-2">
                <Link
                  href={`/tests/${t.id}/take`}
                  className="btn-primary flex flex-1 items-center justify-center gap-1.5 py-2 text-sm"
                >
                  <Play size={15} /> Start
                </Link>
                <button
                  onClick={() => openEdit(t.id)}
                  className="grid h-9 w-9 place-items-center rounded-lg"
                  style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
                >
                  <Pencil size={15} />
                </button>
                <button
                  onClick={() => remove(t.id)}
                  className="grid h-9 w-9 place-items-center rounded-lg"
                  style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                >
                  <Trash2 size={15} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {modalOpen && (
        <div
          className="modal-backdrop fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto p-4"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="surface animate-scale-in my-4 w-full max-w-2xl rounded-2xl p-6 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                {form.id ? "Edit Test" : "New Test"}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg"
                style={{ background: "var(--bg-hover)" }}
              >
                <X size={16} />
              </button>
            </div>

            {/* Test meta */}
            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium">Title</label>
                <input
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="e.g. Physics Full Mock 1"
                  className="input"
                />
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <div className="col-span-2 sm:col-span-1">
                  <label className="mb-1.5 block text-sm font-medium">Subject</label>
                  <select
                    value={form.subjectId}
                    onChange={(e) => setForm({ ...form, subjectId: e.target.value })}
                    className="input"
                  >
                    <option value="">General</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.icon} {s.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium">Time (min)</label>
                  <input
                    type="number"
                    min={1}
                    value={form.durationMinutes}
                    onChange={(e) =>
                      setForm({ ...form, durationMinutes: Number(e.target.value) })
                    }
                    className="input"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium">Marks/Q</label>
                  <input
                    type="number"
                    min={0}
                    step={0.5}
                    value={form.marksPerQuestion}
                    onChange={(e) =>
                      setForm({ ...form, marksPerQuestion: Number(e.target.value) })
                    }
                    className="input"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium">Neg. mark</label>
                  <input
                    type="number"
                    min={0}
                    step={0.25}
                    value={form.negativeMarks}
                    onChange={(e) =>
                      setForm({ ...form, negativeMarks: Number(e.target.value) })
                    }
                    className="input"
                  />
                </div>
              </div>
            </div>

            {/* Questions */}
            <div className="mt-6">
              <div className="mb-2 flex items-center justify-between">
                <h3 className="text-sm font-semibold">
                  Questions ({form.questions.length})
                </h3>
              </div>
              <div className="space-y-4">
                {form.questions.map((q, qi) => (
                  <div
                    key={qi}
                    className="rounded-xl border p-4"
                    style={{ borderColor: "var(--border-color)", background: "var(--bg-hover)" }}
                  >
                    <div className="mb-2 flex items-center justify-between">
                      <span
                        className="flex items-center gap-1.5 text-sm font-semibold"
                        style={{ color: "var(--accent)" }}
                      >
                        <GripVertical size={14} /> Q{qi + 1}
                      </span>
                      {form.questions.length > 1 && (
                        <button
                          onClick={() => removeQuestion(qi)}
                          className="grid h-7 w-7 place-items-center rounded-lg"
                          style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                        >
                          <Trash2 size={13} />
                        </button>
                      )}
                    </div>

                    <textarea
                      value={q.questionText}
                      onChange={(e) => updateQ(qi, { questionText: e.target.value })}
                      placeholder="Type the question…"
                      rows={2}
                      className="input resize-none"
                    />

                    <p className="mb-1.5 mt-3 text-xs font-medium" style={{ color: "var(--text-muted)" }}>
                      Tap the circle to mark the correct answer
                    </p>
                    <div className="space-y-2">
                      {q.options.map((opt, oi) => (
                        <div key={oi} className="flex items-center gap-2">
                          <button
                            onClick={() => updateQ(qi, { correctIndex: oi })}
                            className="grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-all"
                            style={{
                              borderColor:
                                q.correctIndex === oi ? "var(--success)" : "var(--border-color)",
                              background:
                                q.correctIndex === oi ? "var(--success)" : "transparent",
                            }}
                            title="Mark correct"
                          >
                            {q.correctIndex === oi && <Check size={13} color="#fff" />}
                          </button>
                          <input
                            value={opt}
                            onChange={(e) => setOption(qi, oi, e.target.value)}
                            placeholder={`Option ${oi + 1}`}
                            className="input"
                          />
                          {q.options.length > 2 && (
                            <button
                              onClick={() => removeOption(qi, oi)}
                              className="grid h-8 w-8 shrink-0 place-items-center rounded-lg"
                              style={{ color: "var(--text-muted)" }}
                            >
                              <X size={15} />
                            </button>
                          )}
                        </div>
                      ))}
                    </div>
                    {q.options.length < 6 && (
                      <button
                        onClick={() => addOption(qi)}
                        className="mt-2 text-xs font-medium"
                        style={{ color: "var(--accent)" }}
                      >
                        + Add option
                      </button>
                    )}

                    <input
                      value={q.explanation}
                      onChange={(e) => updateQ(qi, { explanation: e.target.value })}
                      placeholder="Explanation (optional, shown in review)"
                      className="input mt-3"
                    />
                  </div>
                ))}
              </div>

              <button
                onClick={addQuestion}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed py-3 text-sm font-medium"
                style={{ borderColor: "var(--border-color)", color: "var(--accent)" }}
              >
                <Plus size={16} /> Add Question
              </button>
            </div>

            {err && (
              <p
                className="mt-4 rounded-lg px-3 py-2 text-sm"
                style={{ background: "var(--danger-light)", color: "var(--danger)" }}
              >
                {err}
              </p>
            )}

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setModalOpen(false)}
                className="flex-1 rounded-xl py-3 text-sm font-medium"
                style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
              >
                Cancel
              </button>
              <button
                onClick={save}
                disabled={saving}
                className="btn-primary flex-1 py-3 text-sm disabled:opacity-50"
              >
                {saving ? "Saving…" : form.id ? "Save Changes" : "Create Test"}
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 10px;
          border: 1px solid var(--border-color);
          background: var(--bg-primary);
          color: var(--text-primary);
          padding: 0.55rem 0.7rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
