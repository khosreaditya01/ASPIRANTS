"use client";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  Cell,
} from "recharts";

interface Props {
  data: { label: string; minutes: number; date: string }[];
}

export function WeeklyChart({ data }: Props) {
  const chartData = data.map((d) => ({
    ...d,
    hours: Math.round((d.minutes / 60) * 10) / 10,
  }));
  const max = Math.max(...chartData.map((d) => d.hours), 1);

  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={chartData} margin={{ top: 10, right: 4, left: -20, bottom: 0 }}>
        <defs>
          <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#6366f1" />
          </linearGradient>
        </defs>
        <XAxis
          dataKey="label"
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--text-muted)", fontSize: 12 }}
        />
        <YAxis
          tickLine={false}
          axisLine={false}
          tick={{ fill: "var(--text-muted)", fontSize: 12 }}
          width={40}
        />
        <Tooltip
          cursor={{ fill: "var(--bg-hover)", radius: 8 }}
          contentStyle={{
            background: "var(--bg-elevated)",
            border: "1px solid var(--border-color)",
            borderRadius: 12,
            color: "var(--text-primary)",
            boxShadow: "var(--shadow-md)",
          }}
          labelStyle={{ color: "var(--text-secondary)" }}
          formatter={(value) => [`${value} h`, "Studied"]}
        />
        <Bar dataKey="hours" radius={[8, 8, 0, 0]} maxBarSize={48}>
          {chartData.map((entry, i) => (
            <Cell
              key={i}
              fill="url(#barGradient)"
              fillOpacity={entry.hours >= max ? 1 : 0.85}
            />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
