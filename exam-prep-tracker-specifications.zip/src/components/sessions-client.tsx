"use client";

import { useEffect, useMemo, useState } from "react";
import { Plus, Trash2, X, Timer, Clock, Layers } from "lucide-react";
import { formatHours, type SessionRow, type Subject } from "@/lib/types";

interface FormState {
  subjectId: string;
  durationMinutes: number;
  date: string;
  notes: string;
}

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export function SessionsClient() {
  const [sessions, setSessions] = useState<SessionRow[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<FormState>({
    subjectId: "",
    durationMinutes: 60,
    date: todayStr(),
    notes: "",
  });

  const load = () => {
    Promise.all([
      fetch("/api/sessions").then((r) => r.json()),
      fetch("/api/subjects").then((r) => r.json()),
    ])
      .then(([s, subj]) => {
        setSessions(Array.isArray(s) ? s : []);
        setSubjects(Array.isArray(subj) ? subj : []);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const grouped = useMemo(() => {
    const map = new Map<string, SessionRow[]>();
    for (const s of sessions) {
      if (!map.has(s.date)) map.set(s.date, []);
      map.get(s.date)!.push(s);
    }
    return Array.from(map.entries()).sort((a, b) => (a[0] < b[0] ? 1 : -1));
  }, [sessions]);

  const totalMinutes = sessions.reduce((a, s) => a + s.durationMinutes, 0);

  const save = async () => {
    if (!form.subjectId || form.durationMinutes <= 0) return;
    setSaving(true);
    await fetch("/api/sessions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
    setModalOpen(false);
    setForm({ subjectId: "", durationMinutes: 60, date: todayStr(), notes: "" });
    setLoading(true);
    load();
  };

  const remove = async (id: number) => {
    await fetch(`/api/sessions?id=${id}`, { method: "DELETE" });
    setSessions((prev) => prev.filter((s) => s.id !== id));
  };

  const openModal = () => {
    setForm({
      subjectId: subjects[0] ? String(subjects[0].id) : "",
      durationMinutes: 60,
      date: todayStr(),
      notes: "",
    });
    setModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Study Sessions</h1>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Log and review your focused study time.
          </p>
        </div>
        <button
          onClick={openModal}
          disabled={subjects.length === 0}
          className="btn-primary flex items-center gap-2 px-5 py-3 text-sm disabled:opacity-50"
        >
          <Plus size={17} /> Log Session
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="surface rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div
              className="grid h-11 w-11 place-items-center rounded-xl"
              style={{ background: "var(--accent-light)", color: "var(--accent)" }}
            >
              <Clock size={20} />
            </div>
            <div>
              <p className="text-2xl font-bold">{formatHours(totalMinutes)}</p>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                Total studied
              </p>
            </div>
          </div>
        </div>
        <div className="surface rounded-2xl p-5">
          <div className="flex items-center gap-3">
            <div
              className="grid h-11 w-11 place-items-center rounded-xl"
              style={{ background: "var(--success-light)", color: "var(--success)" }}
            >
              <Layers size={20} />
            </div>
            <div>
              <p className="text-2xl font-bold">{sessions.length}</p>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                Sessions logged
              </p>
            </div>
          </div>
        </div>
      </div>

      {loading ? (
        <div className="space-y-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="skeleton h-24 rounded-2xl" />
          ))}
        </div>
      ) : subjects.length === 0 ? (
        <div className="surface rounded-2xl py-16 text-center">
          <p className="text-lg font-semibold">No subjects yet</p>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Create a subject first, then log sessions against it.
          </p>
        </div>
      ) : sessions.length === 0 ? (
        <div className="surface flex flex-col items-center gap-3 rounded-2xl py-16 text-center">
          <div
            className="grid h-14 w-14 place-items-center rounded-2xl"
            style={{ background: "var(--accent-light)", color: "var(--accent)" }}
          >
            <Timer size={26} />
          </div>
          <p className="text-lg font-semibold">No sessions yet</p>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            Log your first study session to build your streak.
          </p>
        </div>
      ) : (
        <div className="space-y-6">
          {grouped.map(([date, items]) => {
            const dayTotal = items.reduce((a, s) => a + s.durationMinutes, 0);
            return (
              <div key={date} className="animate-slide-up">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="text-sm font-semibold" style={{ color: "var(--text-secondary)" }}>
                    {new Date(date + "T00:00:00").toLocaleDateString("en-US", {
                      weekday: "long",
                      month: "short",
                      day: "numeric",
                    })}
                  </h3>
                  <span
                    className="rounded-full px-3 py-1 text-xs font-medium"
                    style={{ background: "var(--accent-light)", color: "var(--accent)" }}
                  >
                    {formatHours(dayTotal)}
                  </span>
                </div>
                <div className="space-y-2">
                  {items.map((s) => (
                    <div
                      key={s.id}
                      className="surface card-hover flex items-center gap-4 rounded-xl p-4"
                    >
                      <div
                        className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-lg"
                        style={{ background: (s.subjectColor ?? "#6366f1") + "22" }}
                      >
                        {s.subjectIcon ?? "📘"}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-medium">
                          {s.subjectName ?? "Deleted subject"}
                        </p>
                        {s.notes && (
                          <p
                            className="truncate text-sm"
                            style={{ color: "var(--text-muted)" }}
                          >
                            {s.notes}
                          </p>
                        )}
                      </div>
                      <span
                        className="shrink-0 text-sm font-semibold"
                        style={{ color: "var(--accent)" }}
                      >
                        {formatHours(s.durationMinutes)}
                      </span>
                      <button
                        onClick={() => remove(s.id)}
                        className="grid h-8 w-8 shrink-0 place-items-center rounded-lg transition-colors"
                        style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                      >
                        <Trash2 size={15} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && (
        <div
          className="modal-backdrop fixed inset-0 z-[60] flex items-center justify-center p-4"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="surface animate-scale-in w-full max-w-md rounded-2xl p-6 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">Log Study Session</h2>
              <button
                onClick={() => setModalOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg"
                style={{ background: "var(--bg-hover)" }}
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium">Subject</label>
                <select
                  value={form.subjectId}
                  onChange={(e) => setForm({ ...form, subjectId: e.target.value })}
                  className="input"
                >
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.icon} {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-sm font-medium">
                    Duration (min)
                  </label>
                  <input
                    type="number"
                    min={1}
                    value={form.durationMinutes}
                    onChange={(e) =>
                      setForm({ ...form, durationMinutes: Number(e.target.value) })
                    }
                    className="input"
                  />
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium">Date</label>
                  <input
                    type="date"
                    value={form.date}
                    max={todayStr()}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="input"
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {[25, 45, 60, 90, 120].map((m) => (
                  <button
                    key={m}
                    onClick={() => setForm({ ...form, durationMinutes: m })}
                    className="rounded-lg px-3 py-1.5 text-xs font-medium transition-colors"
                    style={{
                      background:
                        form.durationMinutes === m
                          ? "var(--accent-light)"
                          : "var(--bg-hover)",
                      color:
                        form.durationMinutes === m
                          ? "var(--accent)"
                          : "var(--text-secondary)",
                    }}
                  >
                    {m}m
                  </button>
                ))}
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium">Notes</label>
                <textarea
                  value={form.notes}
                  onChange={(e) => setForm({ ...form, notes: e.target.value })}
                  placeholder="What did you cover?"
                  rows={3}
                  className="input resize-none"
                />
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setModalOpen(false)}
                className="flex-1 rounded-xl py-3 text-sm font-medium"
                style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
              >
                Cancel
              </button>
              <button
                onClick={save}
                disabled={saving || !form.subjectId}
                className="btn-primary flex-1 py-3 text-sm disabled:opacity-50"
              >
                {saving ? "Saving..." : "Log Session"}
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 10px;
          border: 1px solid var(--border-color);
          background: var(--bg-primary);
          color: var(--text-primary);
          padding: 0.6rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
