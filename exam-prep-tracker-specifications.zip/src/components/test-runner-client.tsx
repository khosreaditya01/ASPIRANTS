"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import Link from "next/link";
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Flag,
  Check,
  X,
  Loader2,
  ArrowLeft,
  Trophy,
  RotateCcw,
  CircleCheck,
  CircleX,
  MinusCircle,
} from "lucide-react";
import type { TestDetail, AttemptResult } from "@/lib/types";
import { AddToNotebook } from "./add-to-notebook";

type Phase = "loading" | "intro" | "running" | "submitting" | "result";

function fmtTime(sec: number): string {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function TestRunnerClient({ testId }: { testId: number }) {
  const [phase, setPhase] = useState<Phase>("loading");
  const [test, setTest] = useState<TestDetail | null>(null);
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [flagged, setFlagged] = useState<Set<number>>(new Set());
  const [remaining, setRemaining] = useState(0);
  const [result, setResult] = useState<AttemptResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const startedAt = useRef<number>(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    fetch(`/api/tests/${testId}`)
      .then((r) => r.json())
      .then((d) => {
        if (d.error) {
          setError(d.error);
        } else {
          setTest(d);
          setRemaining(d.durationMinutes * 60);
        }
        setPhase("intro");
      })
      .catch(() => {
        setError("Failed to load test.");
        setPhase("intro");
      });
  }, [testId]);

  const submit = useCallback(
    async (auto = false) => {
      if (!test) return;
      if (timerRef.current) clearInterval(timerRef.current);
      if (!auto) {
        const unanswered = test.questions.length - Object.keys(answers).length;
        if (
          unanswered > 0 &&
          !confirm(`You have ${unanswered} unanswered question(s). Submit anyway?`)
        )
          return;
      }
      setPhase("submitting");
      const timeTaken = Math.round((Date.now() - startedAt.current) / 1000);
      const res = await fetch("/api/attempts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          testId,
          answers: Object.fromEntries(
            Object.entries(answers).map(([k, v]) => [k, v])
          ),
          timeTakenSeconds: timeTaken,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to submit.");
        setPhase("running");
        return;
      }
      setResult(data);
      setPhase("result");
    },
    [test, answers, testId]
  );

  // Timer
  useEffect(() => {
    if (phase !== "running") return;
    timerRef.current = setInterval(() => {
      setRemaining((r) => {
        if (r <= 1) {
          clearInterval(timerRef.current!);
          submit(true);
          return 0;
        }
        return r - 1;
      });
    }, 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [phase, submit]);

  const start = () => {
    startedAt.current = Date.now();
    setPhase("running");
  };

  const select = (qId: number, optIdx: number) =>
    setAnswers((a) => ({ ...a, [qId]: optIdx }));

  const clearAnswer = (qId: number) =>
    setAnswers((a) => {
      const next = { ...a };
      delete next[qId];
      return next;
    });

  const toggleFlag = (idx: number) =>
    setFlagged((f) => {
      const next = new Set(f);
      if (next.has(idx)) next.delete(idx);
      else next.add(idx);
      return next;
    });

  // ---------- RENDER ----------

  if (phase === "loading") {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <Loader2 size={30} className="animate-spin" style={{ color: "var(--accent)" }} />
      </div>
    );
  }

  if (error && !test) {
    return (
      <div className="surface mx-auto max-w-md rounded-2xl p-8 text-center">
        <p className="font-semibold" style={{ color: "var(--danger)" }}>
          {error}
        </p>
        <Link
          href="/tests"
          className="btn-primary mt-4 inline-flex items-center gap-2 px-5 py-2.5 text-sm"
        >
          <ArrowLeft size={16} /> Back to Tests
        </Link>
      </div>
    );
  }

  if (!test) return null;

  // INTRO
  if (phase === "intro") {
    return (
      <div className="surface animate-scale-in mx-auto max-w-lg rounded-2xl p-8 text-center">
        <div
          className="mx-auto grid h-16 w-16 place-items-center rounded-2xl text-white"
          style={{ background: "var(--accent-gradient)" }}
        >
          <Clock size={30} />
        </div>
        <h1 className="mt-4 text-2xl font-bold">{test.title}</h1>
        {test.description && (
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            {test.description}
          </p>
        )}
        <div className="mt-6 grid grid-cols-3 gap-3 text-center">
          <Stat label="Questions" value={String(test.questions.length)} />
          <Stat label="Duration" value={`${test.durationMinutes}m`} />
          <Stat
            label="Marks"
            value={String(test.questions.length * test.marksPerQuestion)}
          />
        </div>
        <div
          className="mt-6 rounded-xl p-4 text-left text-sm"
          style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
        >
          <p>• +{test.marksPerQuestion} for each correct answer.</p>
          {test.negativeMarks > 0 && (
            <p>• −{test.negativeMarks} for each wrong answer.</p>
          )}
          <p>• The test auto-submits when the timer runs out.</p>
        </div>
        {test.questions.length === 0 ? (
          <p className="mt-6 text-sm" style={{ color: "var(--danger)" }}>
            This test has no questions yet.
          </p>
        ) : (
          <button
            onClick={start}
            className="btn-primary mt-6 w-full py-3 text-sm font-semibold"
          >
            Start Test
          </button>
        )}
        <Link
          href="/tests"
          className="mt-3 inline-block text-sm"
          style={{ color: "var(--text-muted)" }}
        >
          Cancel
        </Link>
      </div>
    );
  }

  // SUBMITTING
  if (phase === "submitting") {
    return (
      <div className="grid min-h-[60vh] place-items-center text-center">
        <div>
          <Loader2 size={30} className="mx-auto animate-spin" style={{ color: "var(--accent)" }} />
          <p className="mt-3 text-sm" style={{ color: "var(--text-secondary)" }}>
            Grading your test…
          </p>
        </div>
      </div>
    );
  }

  // RESULT
  if (phase === "result" && result) {
    const pct =
      result.totalMarks > 0
        ? Math.max(0, Math.round((result.score / result.totalMarks) * 100))
        : 0;
    return (
      <div className="space-y-6">
        <div className="surface animate-scale-in rounded-2xl p-8 text-center">
          <div
            className="mx-auto grid h-16 w-16 place-items-center rounded-2xl text-white"
            style={{ background: "var(--accent-gradient)" }}
          >
            <Trophy size={30} />
          </div>
          <p className="mt-3 text-sm" style={{ color: "var(--text-secondary)" }}>
            {test.title}
          </p>
          <h1 className="mt-1 text-4xl font-bold">
            {result.score}
            <span className="text-xl" style={{ color: "var(--text-muted)" }}>
              {" "}
              / {result.totalMarks}
            </span>
          </h1>
          <p className="mt-1 text-sm font-medium" style={{ color: "var(--accent)" }}>
            {pct}% score · finished in {fmtTime(result.timeTakenSeconds)}
          </p>

          <div className="mt-6 grid grid-cols-3 gap-3">
            <ResultStat
              icon={<CircleCheck size={18} />}
              value={result.correctCount}
              label="Correct"
              color="var(--success)"
              bg="var(--success-light)"
            />
            <ResultStat
              icon={<CircleX size={18} />}
              value={result.wrongCount}
              label="Wrong"
              color="var(--danger)"
              bg="var(--danger-light)"
            />
            <ResultStat
              icon={<MinusCircle size={18} />}
              value={result.skippedCount}
              label="Skipped"
              color="var(--warning)"
              bg="var(--warning-light)"
            />
          </div>

          <div className="mt-6 flex justify-center gap-3">
            <Link
              href={`/tests/${testId}/take`}
              className="flex items-center gap-2 rounded-xl px-5 py-2.5 text-sm font-medium"
              style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
            >
              <RotateCcw size={15} /> Retake
            </Link>
            <Link
              href="/tests"
              className="btn-primary flex items-center gap-2 px-5 py-2.5 text-sm"
            >
              <ArrowLeft size={15} /> All Tests
            </Link>
          </div>
        </div>

        {/* Review */}
        <div>
          <h2 className="mb-3 text-lg font-semibold">Answer Review</h2>
          <div className="space-y-3">
            {result.review.map((r, i) => {
              const isCorrect = r.selectedIndex === r.correctIndex;
              const skipped = r.selectedIndex === null;
              return (
                <div key={r.id} className="surface rounded-2xl p-5">
                  <div className="flex items-start gap-2">
                    <span
                      className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full text-xs font-bold text-white"
                      style={{
                        background: skipped
                          ? "var(--warning)"
                          : isCorrect
                            ? "var(--success)"
                            : "var(--danger)",
                      }}
                    >
                      {i + 1}
                    </span>
                    <p className="font-medium">{r.questionText}</p>
                  </div>
                  <div className="mt-3 space-y-2">
                    {r.options.map((opt, oi) => {
                      const isRight = oi === r.correctIndex;
                      const isChosen = oi === r.selectedIndex;
                      let bg = "var(--bg-hover)";
                      let bd = "transparent";
                      if (isRight) {
                        bg = "var(--success-light)";
                        bd = "var(--success)";
                      } else if (isChosen && !isRight) {
                        bg = "var(--danger-light)";
                        bd = "var(--danger)";
                      }
                      return (
                        <div
                          key={oi}
                          className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm"
                          style={{ background: bg, border: `1px solid ${bd}` }}
                        >
                          <span className="flex-1">{opt}</span>
                          {isRight && (
                            <Check size={15} style={{ color: "var(--success)" }} />
                          )}
                          {isChosen && !isRight && (
                            <X size={15} style={{ color: "var(--danger)" }} />
                          )}
                        </div>
                      );
                    })}
                  </div>
                  {r.explanation && (
                    <p
                      className="mt-3 rounded-lg px-3 py-2 text-sm"
                      style={{ background: "var(--accent-light)", color: "var(--text-secondary)" }}
                    >
                      <strong style={{ color: "var(--accent)" }}>Why: </strong>
                      {r.explanation}
                    </p>
                  )}
                  <div className="mt-3 flex justify-end">
                    <AddToNotebook
                      question={{
                        questionText: r.questionText,
                        options: r.options,
                        correctIndex: r.correctIndex,
                        selectedIndex: r.selectedIndex,
                        explanation: r.explanation,
                        sourceTestId: testId,
                        sourceTestTitle: test.title,
                      }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // RUNNING
  const q = test.questions[current];
  const lowTime = remaining <= 30;
  const answeredCount = Object.keys(answers).length;

  return (
    <div className="space-y-5">
      {/* Top bar */}
      <div className="surface sticky top-0 z-30 flex items-center justify-between gap-3 rounded-2xl p-4">
        <div className="min-w-0">
          <h1 className="truncate text-lg font-bold">{test.title}</h1>
          <p className="text-xs" style={{ color: "var(--text-muted)" }}>
            {answeredCount}/{test.questions.length} answered
          </p>
        </div>
        <div
          className="flex items-center gap-2 rounded-xl px-4 py-2 font-bold tabular-nums"
          style={{
            background: lowTime ? "var(--danger-light)" : "var(--accent-light)",
            color: lowTime ? "var(--danger)" : "var(--accent)",
          }}
        >
          <Clock size={17} /> {fmtTime(remaining)}
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-[1fr_240px]">
        {/* Question */}
        <div className="surface flex flex-col rounded-2xl p-6">
          <div className="mb-4 flex items-center justify-between">
            <span
              className="rounded-full px-3 py-1 text-xs font-semibold"
              style={{ background: "var(--accent-light)", color: "var(--accent)" }}
            >
              Question {current + 1} of {test.questions.length}
            </span>
            <button
              onClick={() => toggleFlag(current)}
              className="flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium"
              style={{
                background: flagged.has(current) ? "var(--warning-light)" : "var(--bg-hover)",
                color: flagged.has(current) ? "var(--warning)" : "var(--text-secondary)",
              }}
            >
              <Flag size={13} />{" "}
              {flagged.has(current) ? "Marked for Review" : "Mark for Review"}
            </button>
          </div>

          <p className="text-lg font-medium">{q.questionText}</p>

          <div className="mt-5 space-y-3">
            {q.options.map((opt, oi) => {
              const selected = answers[q.id] === oi;
              return (
                <button
                  key={oi}
                  onClick={() => select(q.id, oi)}
                  className="flex w-full items-center gap-3 rounded-xl border-2 p-4 text-left text-sm transition-all"
                  style={{
                    borderColor: selected ? "var(--accent)" : "var(--border-color)",
                    background: selected ? "var(--accent-light)" : "var(--bg-card)",
                  }}
                >
                  <span
                    className="grid h-7 w-7 shrink-0 place-items-center rounded-full border-2 text-xs font-bold"
                    style={{
                      borderColor: selected ? "var(--accent)" : "var(--border-color)",
                      background: selected ? "var(--accent)" : "transparent",
                      color: selected ? "#fff" : "var(--text-muted)",
                    }}
                  >
                    {String.fromCharCode(65 + oi)}
                  </span>
                  {opt}
                </button>
              );
            })}
          </div>

          <div className="mt-6 flex items-center justify-between gap-3">
            <button
              onClick={() => setCurrent((c) => Math.max(0, c - 1))}
              disabled={current === 0}
              className="flex items-center gap-1.5 rounded-xl px-4 py-2.5 text-sm font-medium disabled:opacity-40"
              style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
            >
              <ChevronLeft size={16} /> Prev
            </button>
            {answers[q.id] !== undefined && (
              <button
                onClick={() => clearAnswer(q.id)}
                className="text-xs font-medium"
                style={{ color: "var(--text-muted)" }}
              >
                Clear answer
              </button>
            )}
            {current < test.questions.length - 1 ? (
              <button
                onClick={() => setCurrent((c) => c + 1)}
                className="btn-primary flex items-center gap-1.5 px-4 py-2.5 text-sm"
              >
                Next <ChevronRight size={16} />
              </button>
            ) : (
              <button
                onClick={() => submit(false)}
                className="btn-primary flex items-center gap-1.5 px-5 py-2.5 text-sm"
              >
                Submit
              </button>
            )}
          </div>
        </div>

        {/* Palette */}
        <div className="surface h-fit rounded-2xl p-5">
          <h3 className="mb-3 text-sm font-semibold">Questions</h3>
          <div className="grid grid-cols-5 gap-2 lg:grid-cols-4">
            {test.questions.map((qq, i) => {
              const answered = answers[qq.id] !== undefined;
              const isFlag = flagged.has(i);
              const isCur = i === current;
              return (
                <button
                  key={qq.id}
                  onClick={() => setCurrent(i)}
                  className="relative grid h-9 w-9 place-items-center rounded-lg text-sm font-semibold transition-all"
                  style={{
                    background: isCur
                      ? "var(--accent)"
                      : answered
                        ? "var(--success-light)"
                        : "var(--bg-hover)",
                    color: isCur
                      ? "#fff"
                      : answered
                        ? "var(--success)"
                        : "var(--text-secondary)",
                    outline: isCur ? "2px solid var(--accent)" : "none",
                    outlineOffset: 1,
                  }}
                >
                  {i + 1}
                  {isFlag && (
                    <span
                      className="absolute -right-1 -top-1 h-2.5 w-2.5 rounded-full"
                      style={{ background: "var(--warning)" }}
                    />
                  )}
                </button>
              );
            })}
          </div>

          <div className="mt-4 space-y-1.5 text-xs" style={{ color: "var(--text-muted)" }}>
            <Legend color="var(--success-light)" label="Answered" />
            <Legend color="var(--bg-hover)" label="Not answered" />
            <Legend color="var(--warning)" label="Marked for review" dot />
          </div>

          <button
            onClick={() => submit(false)}
            className="btn-primary mt-4 w-full py-2.5 text-sm"
          >
            Submit Test
          </button>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl p-3" style={{ background: "var(--bg-hover)" }}>
      <p className="text-xl font-bold">{value}</p>
      <p className="text-xs" style={{ color: "var(--text-muted)" }}>
        {label}
      </p>
    </div>
  );
}

function ResultStat({
  icon,
  value,
  label,
  color,
  bg,
}: {
  icon: React.ReactNode;
  value: number;
  label: string;
  color: string;
  bg: string;
}) {
  return (
    <div className="rounded-xl p-4" style={{ background: bg }}>
      <div className="mx-auto mb-1 grid h-8 w-8 place-items-center" style={{ color }}>
        {icon}
      </div>
      <p className="text-2xl font-bold" style={{ color }}>
        {value}
      </p>
      <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
        {label}
      </p>
    </div>
  );
}

function Legend({
  color,
  label,
  dot,
}: {
  color: string;
  label: string;
  dot?: boolean;
}) {
  return (
    <div className="flex items-center gap-2">
      <span
        className={dot ? "h-2.5 w-2.5 rounded-full" : "h-4 w-4 rounded"}
        style={{ background: color }}
      />
      {label}
    </div>
  );
}
