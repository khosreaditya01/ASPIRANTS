"use client";

import { useEffect, useState } from "react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  BarChart,
  Bar,
  Cell,
  PieChart,
  Pie,
} from "recharts";
import { Clock, Flame, Target, TrendingUp } from "lucide-react";
import { ProgressRing } from "./progress-ring";
import { formatHours, type Stats } from "@/lib/types";

export function AnalyticsClient() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/stats")
      .then((r) => r.json())
      .then(setStats)
      .finally(() => setLoading(false));
  }, []);

  if (loading || !stats) {
    return (
      <div className="space-y-6">
        <div className="skeleton h-10 w-48 rounded-xl" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="skeleton h-28 rounded-2xl" />
          ))}
        </div>
        <div className="skeleton h-72 rounded-2xl" />
      </div>
    );
  }

  const weekly = stats.weekly.map((d) => ({
    ...d,
    hours: Math.round((d.minutes / 60) * 10) / 10,
  }));

  const perSubject = stats.perSubject
    .map((p) => ({
      name: p.name ?? "Unknown",
      color: p.color ?? "#6366f1",
      hours: Math.round((p.totalMinutes / 60) * 10) / 10,
    }))
    .sort((a, b) => b.hours - a.hours);

  const goalData = [
    { name: "Completed", value: stats.completedGoals, color: "#10b981" },
    { name: "Pending", value: stats.pendingGoals, color: "#f59e0b" },
  ];
  const goalPct =
    stats.totalGoals > 0
      ? Math.round((stats.completedGoals / stats.totalGoals) * 100)
      : 0;

  const summary = [
    {
      label: "Total Hours",
      value: formatHours(stats.totalMinutes),
      icon: Clock,
      color: "var(--accent)",
      bg: "var(--accent-light)",
    },
    {
      label: "Day Streak",
      value: `${stats.streak} days`,
      icon: Flame,
      color: "var(--warning)",
      bg: "var(--warning-light)",
    },
    {
      label: "Goals Done",
      value: `${goalPct}%`,
      icon: Target,
      color: "var(--success)",
      bg: "var(--success-light)",
    },
    {
      label: "Avg / Session",
      value:
        stats.sessionCount > 0
          ? formatHours(Math.round(stats.totalMinutes / stats.sessionCount))
          : "0m",
      icon: TrendingUp,
      color: "var(--accent)",
      bg: "var(--accent-light)",
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Analytics</h1>
        <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
          Deep dive into your study patterns.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {summary.map((s, i) => {
          const Icon = s.icon;
          return (
            <div
              key={s.label}
              className={`surface animate-slide-up rounded-2xl p-5 stagger-${i + 1}`}
            >
              <div
                className="grid h-10 w-10 place-items-center rounded-xl"
                style={{ background: s.bg, color: s.color }}
              >
                <Icon size={19} />
              </div>
              <p className="mt-3 text-2xl font-bold">{s.value}</p>
              <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                {s.label}
              </p>
            </div>
          );
        })}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="surface animate-slide-up rounded-2xl p-6 lg:col-span-2">
          <h2 className="mb-4 text-lg font-semibold">Weekly Trend</h2>
          <ResponsiveContainer width="100%" height={280}>
            <AreaChart data={weekly} margin={{ top: 10, right: 6, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#6366f1" stopOpacity={0.5} />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="label"
                tickLine={false}
                axisLine={false}
                tick={{ fill: "var(--text-muted)", fontSize: 12 }}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                tick={{ fill: "var(--text-muted)", fontSize: 12 }}
                width={40}
              />
              <Tooltip
                contentStyle={{
                  background: "var(--bg-elevated)",
                  border: "1px solid var(--border-color)",
                  borderRadius: 12,
                  color: "var(--text-primary)",
                }}
                formatter={(v) => [`${v} h`, "Studied"]}
              />
              <Area
                type="monotone"
                dataKey="hours"
                stroke="#6366f1"
                strokeWidth={2.5}
                fill="url(#areaGrad)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="surface animate-slide-up rounded-2xl p-6">
          <h2 className="mb-2 text-lg font-semibold">Goal Completion</h2>
          {stats.totalGoals === 0 ? (
            <p className="py-16 text-center text-sm" style={{ color: "var(--text-muted)" }}>
              No goals yet.
            </p>
          ) : (
            <div className="relative">
              <ResponsiveContainer width="100%" height={220}>
                <PieChart>
                  <Pie
                    data={goalData}
                    dataKey="value"
                    innerRadius={65}
                    outerRadius={90}
                    paddingAngle={3}
                    startAngle={90}
                    endAngle={-270}
                  >
                    {goalData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      background: "var(--bg-elevated)",
                      border: "1px solid var(--border-color)",
                      borderRadius: 12,
                      color: "var(--text-primary)",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-3xl font-bold">{goalPct}%</span>
                <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                  Complete
                </span>
              </div>
            </div>
          )}
          <div className="mt-4 flex justify-center gap-4">
            {goalData.map((g) => (
              <div key={g.name} className="flex items-center gap-2 text-sm">
                <span
                  className="h-3 w-3 rounded-full"
                  style={{ background: g.color }}
                />
                <span style={{ color: "var(--text-secondary)" }}>
                  {g.name} ({g.value})
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="surface animate-slide-up rounded-2xl p-6">
        <h2 className="mb-4 text-lg font-semibold">Hours per Subject</h2>
        {perSubject.length === 0 ? (
          <p className="py-12 text-center text-sm" style={{ color: "var(--text-muted)" }}>
            Log some sessions to see this chart.
          </p>
        ) : (
          <ResponsiveContainer width="100%" height={Math.max(220, perSubject.length * 52)}>
            <BarChart
              data={perSubject}
              layout="vertical"
              margin={{ top: 0, right: 20, left: 10, bottom: 0 }}
            >
              <XAxis
                type="number"
                tickLine={false}
                axisLine={false}
                tick={{ fill: "var(--text-muted)", fontSize: 12 }}
              />
              <YAxis
                type="category"
                dataKey="name"
                tickLine={false}
                axisLine={false}
                width={100}
                tick={{ fill: "var(--text-secondary)", fontSize: 12 }}
              />
              <Tooltip
                cursor={{ fill: "var(--bg-hover)" }}
                contentStyle={{
                  background: "var(--bg-elevated)",
                  border: "1px solid var(--border-color)",
                  borderRadius: 12,
                  color: "var(--text-primary)",
                }}
                formatter={(v) => [`${v} h`, "Studied"]}
              />
              <Bar dataKey="hours" radius={[0, 8, 8, 0]} maxBarSize={30}>
                {perSubject.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="surface animate-slide-up rounded-2xl p-6">
        <h2 className="mb-4 text-lg font-semibold">Topic Completion</h2>
        {stats.subjects.length === 0 ? (
          <p className="py-12 text-center text-sm" style={{ color: "var(--text-muted)" }}>
            No subjects yet.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {stats.subjects.map((s) => {
              const pct =
                s.totalTopics > 0
                  ? (s.completedTopics / s.totalTopics) * 100
                  : 0;
              return (
                <div
                  key={s.id}
                  className="flex flex-col items-center gap-2 rounded-xl p-3"
                  style={{ background: "var(--bg-hover)" }}
                >
                  <ProgressRing
                    progress={pct}
                    size={68}
                    stroke={7}
                    color={s.color}
                  />
                  <p className="text-center text-sm font-medium">{s.name}</p>
                  <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                    {s.completedTopics}/{s.totalTopics} topics
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
