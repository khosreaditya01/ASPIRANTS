"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import {
  LayoutDashboard,
  BookOpen,
  Timer,
  Target,
  BarChart3,
  Sparkles,
  ClipboardList,
  BookMarked,
  Moon,
  Sun,
  GraduationCap,
  Menu,
  X,
  Quote,
} from "lucide-react";
import { useTheme } from "./theme-provider";

const NAV = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/subjects", label: "Subjects", icon: BookOpen },
  { href: "/sessions", label: "Sessions", icon: Timer },
  { href: "/goals", label: "Goals", icon: Target },
  { href: "/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/tests", label: "Mock Tests", icon: ClipboardList },
  { href: "/notebooks", label: "Mistakes", icon: BookMarked },
  { href: "/doubt-solver", label: "Doubt Solver", icon: Sparkles },
];

const QUOTES = [
  "Success is the sum of small efforts repeated daily.",
  "Discipline beats motivation every single time.",
  "The expert in anything was once a beginner.",
  "Study while others are sleeping.",
  "Your only limit is you. Keep pushing.",
];

export function Sidebar() {
  const pathname = usePathname();
  const { theme, toggleTheme } = useTheme();
  const [open, setOpen] = useState(false);
  const quote = QUOTES[new Date().getDate() % QUOTES.length];

  return (
    <>
      {/* Mobile top bar */}
      <div
        className="lg:hidden sticky top-0 z-40 flex items-center justify-between px-4 py-3 border-b"
        style={{
          background: "var(--bg-sidebar)",
          borderColor: "var(--border-color)",
        }}
      >
        <Link href="/" className="flex items-center gap-2">
          <div
            className="grid h-9 w-9 place-items-center rounded-xl text-white"
            style={{ background: "var(--accent-gradient)" }}
          >
            <GraduationCap size={20} />
          </div>
          <span className="text-lg font-bold">Aspirants</span>
        </Link>
        <button
          onClick={() => setOpen((o) => !o)}
          className="grid h-9 w-9 place-items-center rounded-lg"
          style={{ background: "var(--bg-hover)" }}
          aria-label="Toggle menu"
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {open && (
        <div
          className="lg:hidden fixed inset-0 z-40 modal-backdrop"
          onClick={() => setOpen(false)}
        />
      )}

      <aside
        className={`fixed z-50 top-0 left-0 h-screen w-[260px] flex flex-col border-r transition-transform duration-300 lg:translate-x-0 ${
          open ? "translate-x-0" : "-translate-x-full"
        }`}
        style={{
          background: "var(--bg-sidebar)",
          borderColor: "var(--border-color)",
        }}
      >
        <div className="flex items-center gap-3 px-6 py-6">
          <div
            className="grid h-11 w-11 place-items-center rounded-2xl text-white shadow-md"
            style={{ background: "var(--accent-gradient)" }}
          >
            <GraduationCap size={24} />
          </div>
          <div>
            <h1 className="text-xl font-bold leading-tight">Aspirants</h1>
            <p className="text-xs" style={{ color: "var(--text-muted)" }}>
              Exam Prep Tracker
            </p>
          </div>
        </div>

        <nav className="flex-1 px-3 py-2 space-y-1">
          {NAV.map((item) => {
            const active =
              item.href === "/"
                ? pathname === "/"
                : pathname.startsWith(item.href);
            const Icon = item.icon;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium transition-all"
                style={{
                  background: active ? "var(--accent-light)" : "transparent",
                  color: active ? "var(--accent)" : "var(--text-secondary)",
                }}
              >
                <Icon size={19} />
                {item.label}
                {active && (
                  <span
                    className="ml-auto h-2 w-2 rounded-full"
                    style={{ background: "var(--accent)" }}
                  />
                )}
              </Link>
            );
          })}
        </nav>

        <div className="px-4 pb-4 space-y-3">
          <div
            className="rounded-2xl p-4 text-sm"
            style={{
              background: "var(--bg-hover)",
              color: "var(--text-secondary)",
            }}
          >
            <Quote size={16} style={{ color: "var(--accent)" }} />
            <p className="mt-2 italic leading-relaxed">{quote}</p>
          </div>

          <button
            onClick={toggleTheme}
            className="flex w-full items-center justify-between rounded-xl px-4 py-3 text-sm font-medium transition-colors"
            style={{
              background: "var(--bg-hover)",
              color: "var(--text-secondary)",
            }}
          >
            <span className="flex items-center gap-3">
              {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
              {theme === "light" ? "Dark Mode" : "Light Mode"}
            </span>
            <span
              className="relative h-5 w-9 rounded-full transition-colors"
              style={{
                background: theme === "dark" ? "var(--accent)" : "var(--border-color)",
              }}
            >
              <span
                className="absolute top-0.5 h-4 w-4 rounded-full bg-white transition-transform"
                style={{
                  transform:
                    theme === "dark" ? "translateX(18px)" : "translateX(2px)",
                }}
              />
            </span>
          </button>
        </div>
      </aside>
    </>
  );
}
