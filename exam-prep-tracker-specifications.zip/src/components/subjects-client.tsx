"use client";

import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, X, BookOpen, Clock } from "lucide-react";
import { ProgressRing } from "./progress-ring";
import type { Subject } from "@/lib/types";

const ICONS = [
  "📘", "📗", "📕", "📙", "🧮", "🔬", "⚗️", "🧬", "🌍", "🖥️", "📊", "✍️", "🧠", "📖",
];
const COLORS = [
  "#6366f1", "#8b5cf6", "#ec4899", "#ef4444", "#f59e0b", "#10b981",
  "#06b6d4", "#3b82f6", "#14b8a6", "#f43f5e", "#a855f7", "#84cc16",
];

interface FormState {
  id?: number;
  name: string;
  icon: string;
  color: string;
  totalTopics: number;
  completedTopics: number;
  targetHours: number;
}

const EMPTY: FormState = {
  name: "",
  icon: "📘",
  color: "#6366f1",
  totalTopics: 0,
  completedTopics: 0,
  targetHours: 0,
};

export function SubjectsClient() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY);
  const [saving, setSaving] = useState(false);

  const load = () => {
    fetch("/api/subjects")
      .then((r) => r.json())
      .then((d) => setSubjects(Array.isArray(d) ? d : []))
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const openCreate = () => {
    setForm(EMPTY);
    setModalOpen(true);
  };
  const openEdit = (s: Subject) => {
    setForm({
      id: s.id,
      name: s.name,
      icon: s.icon,
      color: s.color,
      totalTopics: s.totalTopics,
      completedTopics: s.completedTopics,
      targetHours: s.targetHours,
    });
    setModalOpen(true);
  };

  const save = async () => {
    if (!form.name.trim()) return;
    setSaving(true);
    const method = form.id ? "PUT" : "POST";
    await fetch("/api/subjects", {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
    setModalOpen(false);
    setLoading(true);
    load();
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this subject and all its sessions?")) return;
    await fetch(`/api/subjects?id=${id}`, { method: "DELETE" });
    setSubjects((prev) => prev.filter((s) => s.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Subjects</h1>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Manage the subjects you&apos;re preparing for.
          </p>
        </div>
        <button
          onClick={openCreate}
          className="btn-primary flex items-center gap-2 px-5 py-3 text-sm"
        >
          <Plus size={17} /> Add Subject
        </button>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-44 rounded-2xl" />
          ))}
        </div>
      ) : subjects.length === 0 ? (
        <div className="surface flex flex-col items-center gap-3 rounded-2xl py-16 text-center">
          <div
            className="grid h-14 w-14 place-items-center rounded-2xl"
            style={{ background: "var(--accent-light)", color: "var(--accent)" }}
          >
            <BookOpen size={26} />
          </div>
          <p className="text-lg font-semibold">No subjects yet</p>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            Add your first subject to start tracking progress.
          </p>
          <button
            onClick={openCreate}
            className="btn-primary mt-2 flex items-center gap-2 px-5 py-2.5 text-sm"
          >
            <Plus size={16} /> Add Subject
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {subjects.map((s, i) => {
            const progress =
              s.totalTopics > 0
                ? (s.completedTopics / s.totalTopics) * 100
                : 0;
            const remaining = Math.max(0, s.totalTopics - s.completedTopics);
            return (
              <div
                key={s.id}
                className={`surface card-hover animate-slide-up rounded-2xl p-5 stagger-${(i % 5) + 1}`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="grid h-12 w-12 place-items-center rounded-xl text-2xl"
                      style={{ background: s.color + "22" }}
                    >
                      {s.icon}
                    </div>
                    <div>
                      <h3 className="font-semibold leading-tight">{s.name}</h3>
                      <p
                        className="flex items-center gap-1 text-xs"
                        style={{ color: "var(--text-muted)" }}
                      >
                        <Clock size={12} /> {s.targetHours}h target
                      </p>
                    </div>
                  </div>
                  <ProgressRing
                    progress={progress}
                    size={56}
                    stroke={6}
                    color={s.color}
                  />
                </div>

                <div className="mt-4">
                  <div className="flex justify-between text-xs" style={{ color: "var(--text-secondary)" }}>
                    <span>
                      {s.completedTopics}/{s.totalTopics} topics
                    </span>
                    <span>{remaining} left</span>
                  </div>
                  <div
                    className="mt-1.5 h-2 overflow-hidden rounded-full"
                    style={{ background: "var(--bg-hover)" }}
                  >
                    <div
                      className="h-full rounded-full transition-all"
                      style={{
                        width: `${progress}%`,
                        background: s.color,
                      }}
                    />
                  </div>
                </div>

                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => openEdit(s)}
                    className="flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-medium transition-colors"
                    style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
                  >
                    <Pencil size={14} /> Edit
                  </button>
                  <button
                    onClick={() => remove(s.id)}
                    className="grid h-9 w-9 place-items-center rounded-lg transition-colors"
                    style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                  >
                    <Trash2 size={15} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && (
        <div
          className="modal-backdrop fixed inset-0 z-[60] flex items-center justify-center p-4"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="surface animate-scale-in w-full max-w-md rounded-2xl p-6 shadow-lg"
            onClick={(e) => e.stopPropagation()}
            style={{ maxHeight: "90vh", overflowY: "auto" }}
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                {form.id ? "Edit Subject" : "New Subject"}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg"
                style={{ background: "var(--bg-hover)" }}
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-4">
              <Field label="Subject Name">
                <input
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="e.g. Mathematics"
                  className="input"
                />
              </Field>

              <div>
                <label className="mb-2 block text-sm font-medium">Icon</label>
                <div className="flex flex-wrap gap-2">
                  {ICONS.map((ic) => (
                    <button
                      key={ic}
                      onClick={() => setForm({ ...form, icon: ic })}
                      className="grid h-9 w-9 place-items-center rounded-lg text-lg transition-all"
                      style={{
                        background:
                          form.icon === ic ? "var(--accent-light)" : "var(--bg-hover)",
                        outline:
                          form.icon === ic ? "2px solid var(--accent)" : "none",
                      }}
                    >
                      {ic}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium">Color</label>
                <div className="flex flex-wrap gap-2">
                  {COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => setForm({ ...form, color: c })}
                      className="h-8 w-8 rounded-full transition-transform"
                      style={{
                        background: c,
                        transform: form.color === c ? "scale(1.15)" : "scale(1)",
                        outline:
                          form.color === c ? "2px solid var(--text-primary)" : "none",
                        outlineOffset: 2,
                      }}
                    />
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <Field label="Total Topics">
                  <input
                    type="number"
                    min={0}
                    value={form.totalTopics}
                    onChange={(e) =>
                      setForm({ ...form, totalTopics: Number(e.target.value) })
                    }
                    className="input"
                  />
                </Field>
                <Field label="Completed">
                  <input
                    type="number"
                    min={0}
                    value={form.completedTopics}
                    onChange={(e) =>
                      setForm({ ...form, completedTopics: Number(e.target.value) })
                    }
                    className="input"
                  />
                </Field>
                <Field label="Target Hrs">
                  <input
                    type="number"
                    min={0}
                    value={form.targetHours}
                    onChange={(e) =>
                      setForm({ ...form, targetHours: Number(e.target.value) })
                    }
                    className="input"
                  />
                </Field>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setModalOpen(false)}
                className="flex-1 rounded-xl py-3 text-sm font-medium"
                style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
              >
                Cancel
              </button>
              <button
                onClick={save}
                disabled={saving || !form.name.trim()}
                className="btn-primary flex-1 py-3 text-sm disabled:opacity-50"
              >
                {saving ? "Saving..." : form.id ? "Save Changes" : "Create"}
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 10px;
          border: 1px solid var(--border-color);
          background: var(--bg-primary);
          color: var(--text-primary);
          padding: 0.6rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-medium">{label}</label>
      {children}
    </div>
  );
}
