"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import {
  Sparkles,
  UploadCloud,
  ImageIcon,
  Loader2,
  X,
  Trash2,
  AlertTriangle,
  History,
  RotateCcw,
  Lightbulb,
} from "lucide-react";
import type { DoubtRow, Subject } from "@/lib/types";

/** Downscale + compress an image file to a data URL to keep payloads small. */
function compressImage(file: File, maxDim = 1280, quality = 0.82): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        let { width, height } = img;
        if (width > maxDim || height > maxDim) {
          const scale = Math.min(maxDim / width, maxDim / height);
          width = Math.round(width * scale);
          height = Math.round(height * scale);
        }
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        if (!ctx) return reject(new Error("Canvas unsupported"));
        ctx.drawImage(img, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.onerror = reject;
      img.src = reader.result as string;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function DoubtSolverClient() {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [history, setHistory] = useState<DoubtRow[]>([]);
  const [image, setImage] = useState<string | null>(null);
  const [prompt, setPrompt] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [answer, setAnswer] = useState<string | null>(null);
  const [solving, setSolving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const loadHistory = useCallback(() => {
    fetch("/api/doubts")
      .then((r) => r.json())
      .then((d) => setHistory(Array.isArray(d) ? d : []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    fetch("/api/subjects")
      .then((r) => r.json())
      .then((d) => setSubjects(Array.isArray(d) ? d : []))
      .catch(() => {});
    loadHistory();
  }, [loadHistory]);

  const solve = useCallback(
    async (dataUrl: string, note: string, subj: string) => {
      setSolving(true);
      setError(null);
      setAnswer(null);
      try {
        const res = await fetch("/api/doubts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            image: dataUrl,
            prompt: note,
            subjectId: subj || null,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          setError(data.error || "Something went wrong.");
        } else {
          setAnswer(data.answer);
          loadHistory();
        }
      } catch {
        setError("Network error. Please try again.");
      } finally {
        setSolving(false);
      }
    },
    [loadHistory]
  );

  const handleFile = useCallback(
    async (file: File) => {
      if (!file.type.startsWith("image/")) {
        setError("Please upload an image file.");
        return;
      }
      setError(null);
      try {
        const dataUrl = await compressImage(file);
        setImage(dataUrl);
        setAnswer(null);
        // Auto-solve immediately on upload.
        solve(dataUrl, prompt, subjectId);
      } catch {
        setError("Could not read that image. Try another one.");
      }
    },
    [prompt, subjectId, solve]
  );

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  // Allow pasting a screenshot directly.
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const item = Array.from(e.clipboardData?.items ?? []).find((i) =>
        i.type.startsWith("image/")
      );
      const file = item?.getAsFile();
      if (file) handleFile(file);
    };
    window.addEventListener("paste", onPaste);
    return () => window.removeEventListener("paste", onPaste);
  }, [handleFile]);

  const reset = () => {
    setImage(null);
    setAnswer(null);
    setError(null);
    setPrompt("");
  };

  const removeHistory = async (id: number) => {
    await fetch(`/api/doubts?id=${id}`, { method: "DELETE" });
    setHistory((prev) => prev.filter((h) => h.id !== id));
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 text-3xl font-bold">
            AI Doubt Solver
            <span
              className="rounded-full px-2.5 py-0.5 text-xs font-semibold"
              style={{ background: "var(--accent-light)", color: "var(--accent)" }}
            >
              Beta
            </span>
          </h1>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Snap or upload a question — get a step-by-step solution instantly.
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Left: upload + controls */}
        <div className="space-y-4">
          <div className="surface rounded-2xl p-5">
            <div className="mb-3 grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1.5 block text-sm font-medium">
                  Subject (optional)
                </label>
                <select
                  value={subjectId}
                  onChange={(e) => setSubjectId(e.target.value)}
                  className="input"
                >
                  <option value="">General</option>
                  {subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.icon} {s.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium">
                  Note (optional)
                </label>
                <input
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="e.g. explain step 2"
                  className="input"
                />
              </div>
            </div>

            {!image ? (
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                onClick={() => fileRef.current?.click()}
                className="flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed py-14 text-center transition-colors"
                style={{
                  borderColor: dragOver ? "var(--accent)" : "var(--border-color)",
                  background: dragOver ? "var(--accent-light)" : "var(--bg-hover)",
                }}
              >
                <div
                  className="grid h-14 w-14 place-items-center rounded-2xl text-white"
                  style={{ background: "var(--accent-gradient)" }}
                >
                  <UploadCloud size={26} />
                </div>
                <div>
                  <p className="font-semibold">Drop an image, click to browse</p>
                  <p className="mt-1 text-xs" style={{ color: "var(--text-muted)" }}>
                    or paste a screenshot (Ctrl/⌘ + V) · solves automatically
                  </p>
                </div>
              </div>
            ) : (
              <div className="relative overflow-hidden rounded-2xl border" style={{ borderColor: "var(--border-color)" }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={image} alt="Uploaded doubt" className="max-h-[360px] w-full object-contain" style={{ background: "var(--bg-hover)" }} />
                <div className="absolute right-2 top-2 flex gap-2">
                  <button
                    onClick={reset}
                    className="grid h-9 w-9 place-items-center rounded-lg text-white shadow-md"
                    style={{ background: "rgba(0,0,0,0.55)" }}
                    title="Remove"
                  >
                    <X size={16} />
                  </button>
                </div>
              </div>
            )}

            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleFile(f);
                e.target.value = "";
              }}
            />

            {image && (
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => solve(image, prompt, subjectId)}
                  disabled={solving}
                  className="btn-primary flex flex-1 items-center justify-center gap-2 py-2.5 text-sm disabled:opacity-60"
                >
                  {solving ? (
                    <>
                      <Loader2 size={16} className="animate-spin" /> Solving…
                    </>
                  ) : (
                    <>
                      <RotateCcw size={16} /> Re-solve
                    </>
                  )}
                </button>
                <button
                  onClick={() => fileRef.current?.click()}
                  className="flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-medium"
                  style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
                >
                  <ImageIcon size={16} /> New
                </button>
              </div>
            )}
          </div>

          <div
            className="flex items-start gap-3 rounded-2xl p-4 text-sm"
            style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
          >
            <Lightbulb size={18} style={{ color: "var(--warning)" }} className="mt-0.5 shrink-0" />
            <p>
              Tip: crop tightly around a single question and ensure text is legible
              for the best results. Handwritten doubts work too!
            </p>
          </div>
        </div>

        {/* Right: solution */}
        <div className="surface flex min-h-[300px] flex-col rounded-2xl p-6">
          <div className="mb-4 flex items-center gap-2">
            <div
              className="grid h-9 w-9 place-items-center rounded-xl text-white"
              style={{ background: "var(--accent-gradient)" }}
            >
              <Sparkles size={18} />
            </div>
            <h2 className="text-lg font-semibold">Solution</h2>
          </div>

          {solving ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
              <Loader2 size={30} className="animate-spin" style={{ color: "var(--accent)" }} />
              <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                Analyzing your question and working through it…
              </p>
            </div>
          ) : error ? (
            <div
              className="flex flex-1 flex-col items-center justify-center gap-3 rounded-xl p-6 text-center"
              style={{ background: "var(--danger-light)" }}
            >
              <AlertTriangle size={26} style={{ color: "var(--danger)" }} />
              <p className="text-sm font-medium" style={{ color: "var(--danger)" }}>
                {error}
              </p>
            </div>
          ) : answer ? (
            <div className="markdown-body animate-fade-in text-sm leading-relaxed">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>{answer}</ReactMarkdown>
            </div>
          ) : (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center" style={{ color: "var(--text-muted)" }}>
              <Sparkles size={30} />
              <p className="text-sm">
                Upload a question image and the solution will appear here.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="surface rounded-2xl p-6">
          <div className="mb-4 flex items-center gap-2">
            <History size={18} style={{ color: "var(--accent)" }} />
            <h2 className="text-lg font-semibold">Recent Doubts</h2>
          </div>
          <div className="space-y-3">
            {history.map((h) => (
              <details
                key={h.id}
                className="group rounded-xl p-4"
                style={{ background: "var(--bg-hover)" }}
              >
                <summary className="flex cursor-pointer list-none items-center gap-3">
                  <span
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg text-white"
                    style={{ background: "var(--accent-gradient)" }}
                  >
                    <Sparkles size={15} />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">
                      {h.prompt || firstLine(h.answer)}
                    </p>
                    <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                      {h.subjectName ? `${h.subjectName} · ` : ""}
                      {new Date(h.createdAt).toLocaleString("en-US", {
                        month: "short",
                        day: "numeric",
                        hour: "numeric",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.preventDefault();
                      removeHistory(h.id);
                    }}
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg"
                    style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                  >
                    <Trash2 size={14} />
                  </button>
                </summary>
                <div
                  className="markdown-body mt-3 border-t pt-3 text-sm leading-relaxed"
                  style={{ borderColor: "var(--border-color)" }}
                >
                  <ReactMarkdown remarkPlugins={[remarkGfm]}>{h.answer}</ReactMarkdown>
                </div>
              </details>
            ))}
          </div>
        </div>
      )}

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 10px;
          border: 1px solid var(--border-color);
          background: var(--bg-primary);
          color: var(--text-primary);
          padding: 0.6rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}

function firstLine(text: string): string {
  const clean = text.replace(/[#*`>_-]/g, "").trim();
  return clean.split("\n")[0].slice(0, 80) || "Solved doubt";
}
