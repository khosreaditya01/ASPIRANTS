"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
  Clock,
  BookOpen,
  CheckCircle2,
  Flame,
  ArrowRight,
  Target,
  Calendar,
  RefreshCw,
  AlertTriangle,
} from "lucide-react";
import { WeeklyChart } from "./weekly-chart";
import { formatHours, type Stats } from "@/lib/types";

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Good Morning";
  if (h < 18) return "Good Afternoon";
  return "Good Evening";
}

const PRIORITY_COLORS: Record<string, string> = {
  low: "var(--success)",
  medium: "var(--warning)",
  high: "var(--danger)",
};

function dueLabel(targetDate: string | null): string {
  if (!targetDate) return "No date";
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const d = new Date(targetDate + "T00:00:00");
  const diff = Math.round((d.getTime() - today.getTime()) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Tomorrow";
  if (diff < 0) return `${Math.abs(diff)}d overdue`;
  return `${diff}d left`;
}

export function DashboardClient() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  const loadStats = () => {
    setLoading(true);
    setFailed(false);
    fetch("/api/stats")
      .then((r) => {
        if (!r.ok) throw new Error("Request failed");
        return r.json();
      })
      .then((d) => {
        // Validate the shape so a stray error object can't break rendering.
        if (!d || typeof d !== "object" || !Array.isArray(d.weekly)) {
          throw new Error("Invalid response");
        }
        setStats(d as Stats);
      })
      .catch(() => setFailed(true))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadStats();
  }, []);

  const cards = stats
    ? [
        {
          label: "Study Hours",
          value: formatHours(stats.totalMinutes),
          icon: Clock,
          gradient: "linear-gradient(135deg, #6366f1, #8b5cf6)",
        },
        {
          label: "Subjects",
          value: String(stats.subjectCount),
          icon: BookOpen,
          gradient: "linear-gradient(135deg, #06b6d4, #3b82f6)",
        },
        {
          label: "Goals Done",
          value: `${stats.completedGoals}/${stats.totalGoals}`,
          icon: CheckCircle2,
          gradient: "linear-gradient(135deg, #10b981, #059669)",
        },
        {
          label: "Day Streak",
          value: `${stats.streak}`,
          icon: Flame,
          gradient: "linear-gradient(135deg, #f59e0b, #ef4444)",
        },
      ]
    : [];

  if (failed) {
    return (
      <div className="grid min-h-[60vh] place-items-center">
        <div className="surface max-w-md rounded-2xl p-8 text-center">
          <div
            className="mx-auto grid h-14 w-14 place-items-center rounded-2xl"
            style={{ background: "var(--danger-light)", color: "var(--danger)" }}
          >
            <AlertTriangle size={26} />
          </div>
          <p className="mt-4 text-lg font-semibold">Couldn&apos;t load your dashboard</p>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            The server didn&apos;t respond. Check your connection and try again.
          </p>
          <button
            onClick={loadStats}
            className="btn-primary mx-auto mt-5 flex items-center gap-2 px-5 py-2.5 text-sm"
          >
            <RefreshCw size={16} /> Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="animate-fade-in flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="text-sm font-medium" style={{ color: "var(--accent)" }}>
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              month: "long",
              day: "numeric",
            })}
          </p>
          <h1 className="mt-1 text-3xl font-bold">{greeting()}, Aspirant 👋</h1>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Here&apos;s your study progress at a glance.
          </p>
        </div>
        <Link
          href="/sessions"
          className="btn-primary flex items-center gap-2 px-5 py-3 text-sm"
        >
          <Clock size={17} /> Log a Session
        </Link>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="skeleton h-32 rounded-2xl" />
            ))
          : cards.map((c, i) => {
              const Icon = c.icon;
              return (
                <div
                  key={c.label}
                  className={`animate-slide-up card-hover rounded-2xl p-5 text-white shadow-md stagger-${i + 1}`}
                  style={{ background: c.gradient }}
                >
                  <div className="flex items-center justify-between">
                    <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/20">
                      <Icon size={20} />
                    </div>
                  </div>
                  <p className="mt-4 text-3xl font-bold">{c.value}</p>
                  <p className="mt-1 text-sm text-white/85">{c.label}</p>
                </div>
              );
            })}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Weekly chart */}
        <div className="surface animate-slide-up stagger-2 rounded-2xl p-6 lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-lg font-semibold">Weekly Activity</h2>
              <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                Hours studied over the last 7 days
              </p>
            </div>
            <Calendar size={20} style={{ color: "var(--text-muted)" }} />
          </div>
          {loading ? (
            <div className="skeleton h-[260px] rounded-xl" />
          ) : (
            <WeeklyChart data={stats!.weekly} />
          )}
        </div>

        {/* Upcoming goals */}
        <div className="surface animate-slide-up stagger-3 rounded-2xl p-6">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Upcoming Goals</h2>
            <Link href="/goals" style={{ color: "var(--accent)" }}>
              <ArrowRight size={18} />
            </Link>
          </div>
          <div className="space-y-3">
            {loading ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="skeleton h-14 rounded-xl" />
              ))
            ) : stats!.upcomingGoals.length === 0 ? (
              <EmptyMini
                icon={<Target size={22} />}
                text="No pending goals. Add one!"
              />
            ) : (
              stats!.upcomingGoals.map((g) => (
                <div
                  key={g.id}
                  className="flex items-center gap-3 rounded-xl p-3"
                  style={{ background: "var(--bg-hover)" }}
                >
                  <span
                    className="h-9 w-1.5 shrink-0 rounded-full"
                    style={{ background: PRIORITY_COLORS[g.priority] }}
                  />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{g.title}</p>
                    <p
                      className="text-xs"
                      style={{ color: "var(--text-muted)" }}
                    >
                      {g.subjectName ?? "General"}
                    </p>
                  </div>
                  <span
                    className="shrink-0 text-xs font-medium"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {dueLabel(g.targetDate)}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Recent sessions */}
      <div className="surface animate-slide-up stagger-4 rounded-2xl p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold">Recent Sessions</h2>
          <Link
            href="/sessions"
            className="flex items-center gap-1 text-sm font-medium"
            style={{ color: "var(--accent)" }}
          >
            View all <ArrowRight size={15} />
          </Link>
        </div>
        <div className="space-y-2">
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="skeleton h-16 rounded-xl" />
            ))
          ) : stats!.recentSessions.length === 0 ? (
            <EmptyMini
              icon={<Clock size={22} />}
              text="No sessions yet. Log your first study session!"
            />
          ) : (
            stats!.recentSessions.map((s) => (
              <div
                key={s.id}
                className="flex items-center gap-4 rounded-xl p-3 transition-colors hover:bg-[var(--bg-hover)]"
              >
                <div
                  className="grid h-11 w-11 shrink-0 place-items-center rounded-xl text-lg"
                  style={{
                    background: (s.subjectColor ?? "#6366f1") + "22",
                  }}
                >
                  {s.subjectIcon ?? "📘"}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">
                    {s.subjectName ?? "Deleted subject"}
                  </p>
                  <p className="truncate text-xs" style={{ color: "var(--text-muted)" }}>
                    {s.notes || "No notes"}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold" style={{ color: "var(--accent)" }}>
                    {formatHours(s.durationMinutes)}
                  </p>
                  <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                    {new Date(s.date + "T00:00:00").toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                    })}
                  </p>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function EmptyMini({ icon, text }: { icon: React.ReactNode; text: string }) {
  return (
    <div
      className="flex flex-col items-center gap-2 rounded-xl py-8 text-center"
      style={{ color: "var(--text-muted)" }}
    >
      {icon}
      <p className="text-sm">{text}</p>
    </div>
  );
}
