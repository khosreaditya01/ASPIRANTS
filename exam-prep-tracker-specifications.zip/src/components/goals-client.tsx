"use client";

import { useEffect, useState } from "react";
import {
  Plus,
  Pencil,
  Trash2,
  X,
  Target,
  Check,
  Flag,
} from "lucide-react";
import type { GoalRow, Subject } from "@/lib/types";

type Filter = "all" | "pending" | "completed";

interface FormState {
  id?: number;
  title: string;
  description: string;
  subjectId: string;
  targetDate: string;
  priority: string;
}

const EMPTY: FormState = {
  title: "",
  description: "",
  subjectId: "",
  targetDate: "",
  priority: "medium",
};

const PRIORITY: Record<string, { color: string; light: string; label: string }> = {
  low: { color: "var(--success)", light: "var(--success-light)", label: "Low" },
  medium: { color: "var(--warning)", light: "var(--warning-light)", label: "Medium" },
  high: { color: "var(--danger)", light: "var(--danger-light)", label: "High" },
};

function dueLabel(targetDate: string | null): { text: string; overdue: boolean } {
  if (!targetDate) return { text: "No date", overdue: false };
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const d = new Date(targetDate + "T00:00:00");
  const diff = Math.round((d.getTime() - today.getTime()) / 86400000);
  if (diff === 0) return { text: "Today", overdue: false };
  if (diff === 1) return { text: "Tomorrow", overdue: false };
  if (diff < 0) return { text: `${Math.abs(diff)}d overdue`, overdue: true };
  return { text: `${diff}d left`, overdue: false };
}

export function GoalsClient() {
  const [goals, setGoals] = useState<GoalRow[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<Filter>("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<FormState>(EMPTY);

  const load = () => {
    Promise.all([
      fetch("/api/goals").then((r) => r.json()),
      fetch("/api/subjects").then((r) => r.json()),
    ])
      .then(([g, s]) => {
        setGoals(Array.isArray(g) ? g : []);
        setSubjects(Array.isArray(s) ? s : []);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const counts = {
    all: goals.length,
    pending: goals.filter((g) => !g.completed).length,
    completed: goals.filter((g) => g.completed).length,
  };

  const filtered = goals.filter((g) =>
    filter === "all"
      ? true
      : filter === "completed"
        ? g.completed
        : !g.completed
  );

  const save = async () => {
    if (!form.title.trim()) return;
    setSaving(true);
    await fetch("/api/goals", {
      method: form.id ? "PUT" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setSaving(false);
    setModalOpen(false);
    setLoading(true);
    load();
  };

  const toggle = async (g: GoalRow) => {
    setGoals((prev) =>
      prev.map((x) => (x.id === g.id ? { ...x, completed: !x.completed } : x))
    );
    await fetch("/api/goals", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: g.id, completed: !g.completed }),
    });
  };

  const remove = async (id: number) => {
    if (!confirm("Delete this goal?")) return;
    await fetch(`/api/goals?id=${id}`, { method: "DELETE" });
    setGoals((prev) => prev.filter((g) => g.id !== id));
  };

  const openCreate = () => {
    setForm(EMPTY);
    setModalOpen(true);
  };
  const openEdit = (g: GoalRow) => {
    setForm({
      id: g.id,
      title: g.title,
      description: g.description ?? "",
      subjectId: g.subjectId ? String(g.subjectId) : "",
      targetDate: g.targetDate ?? "",
      priority: g.priority,
    });
    setModalOpen(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Goals</h1>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Set targets and track your milestones.
          </p>
        </div>
        <button
          onClick={openCreate}
          className="btn-primary flex items-center gap-2 px-5 py-3 text-sm"
        >
          <Plus size={17} /> Add Goal
        </button>
      </div>

      <div className="flex gap-2">
        {(["all", "pending", "completed"] as Filter[]).map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className="flex items-center gap-2 rounded-xl px-4 py-2 text-sm font-medium capitalize transition-colors"
            style={{
              background: filter === f ? "var(--accent)" : "var(--bg-card)",
              color: filter === f ? "#fff" : "var(--text-secondary)",
              border: `1px solid ${filter === f ? "var(--accent)" : "var(--border-color)"}`,
            }}
          >
            {f}
            <span
              className="rounded-full px-2 py-0.5 text-xs"
              style={{
                background: filter === f ? "rgba(255,255,255,0.25)" : "var(--bg-hover)",
              }}
            >
              {counts[f]}
            </span>
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-3">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="skeleton h-24 rounded-2xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="surface flex flex-col items-center gap-3 rounded-2xl py-16 text-center">
          <div
            className="grid h-14 w-14 place-items-center rounded-2xl"
            style={{ background: "var(--accent-light)", color: "var(--accent)" }}
          >
            <Target size={26} />
          </div>
          <p className="text-lg font-semibold">
            {filter === "all" ? "No goals yet" : `No ${filter} goals`}
          </p>
          <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
            Add a goal to keep yourself accountable.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((g, i) => {
            const pri = PRIORITY[g.priority] ?? PRIORITY.medium;
            const due = dueLabel(g.targetDate);
            return (
              <div
                key={g.id}
                className={`surface card-hover animate-slide-up flex items-start gap-4 rounded-2xl p-4 stagger-${(i % 5) + 1}`}
                style={{ opacity: g.completed ? 0.65 : 1 }}
              >
                <button
                  onClick={() => toggle(g)}
                  className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-full border-2 transition-all"
                  style={{
                    borderColor: g.completed ? "var(--success)" : "var(--border-color)",
                    background: g.completed ? "var(--success)" : "transparent",
                  }}
                >
                  {g.completed && <Check size={14} color="#fff" />}
                </button>

                <div className="min-w-0 flex-1">
                  <p
                    className="font-medium"
                    style={{
                      textDecoration: g.completed ? "line-through" : "none",
                    }}
                  >
                    {g.title}
                  </p>
                  {g.description && (
                    <p className="mt-0.5 text-sm" style={{ color: "var(--text-muted)" }}>
                      {g.description}
                    </p>
                  )}
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <span
                      className="flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium"
                      style={{ background: pri.light, color: pri.color }}
                    >
                      <Flag size={11} /> {pri.label}
                    </span>
                    {g.subjectName && (
                      <span
                        className="rounded-full px-2.5 py-0.5 text-xs font-medium"
                        style={{
                          background: (g.subjectColor ?? "#6366f1") + "22",
                          color: g.subjectColor ?? "var(--accent)",
                        }}
                      >
                        {g.subjectName}
                      </span>
                    )}
                    {!g.completed && (
                      <span
                        className="text-xs font-medium"
                        style={{
                          color: due.overdue ? "var(--danger)" : "var(--text-muted)",
                        }}
                      >
                        {due.text}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex shrink-0 gap-2">
                  <button
                    onClick={() => openEdit(g)}
                    className="grid h-8 w-8 place-items-center rounded-lg transition-colors"
                    style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
                  >
                    <Pencil size={14} />
                  </button>
                  <button
                    onClick={() => remove(g.id)}
                    className="grid h-8 w-8 place-items-center rounded-lg transition-colors"
                    style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {modalOpen && (
        <div
          className="modal-backdrop fixed inset-0 z-[60] flex items-center justify-center p-4"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="surface animate-scale-in w-full max-w-md rounded-2xl p-6 shadow-lg"
            onClick={(e) => e.stopPropagation()}
            style={{ maxHeight: "90vh", overflowY: "auto" }}
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">
                {form.id ? "Edit Goal" : "New Goal"}
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg"
                style={{ background: "var(--bg-hover)" }}
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium">Title</label>
                <input
                  value={form.title}
                  onChange={(e) => setForm({ ...form, title: e.target.value })}
                  placeholder="e.g. Finish Algebra chapter"
                  className="input"
                />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-medium">
                  Description
                </label>
                <textarea
                  value={form.description}
                  onChange={(e) =>
                    setForm({ ...form, description: e.target.value })
                  }
                  rows={2}
                  placeholder="Optional details"
                  className="input resize-none"
                />
              </div>

              <div>
                <label className="mb-1.5 block text-sm font-medium">Priority</label>
                <div className="flex gap-2">
                  {Object.entries(PRIORITY).map(([key, val]) => (
                    <button
                      key={key}
                      onClick={() => setForm({ ...form, priority: key })}
                      className="flex-1 rounded-lg py-2 text-sm font-medium capitalize transition-all"
                      style={{
                        background:
                          form.priority === key ? val.light : "var(--bg-hover)",
                        color:
                          form.priority === key ? val.color : "var(--text-secondary)",
                        outline:
                          form.priority === key ? `1.5px solid ${val.color}` : "none",
                      }}
                    >
                      {val.label}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="mb-1.5 block text-sm font-medium">Subject</label>
                  <select
                    value={form.subjectId}
                    onChange={(e) =>
                      setForm({ ...form, subjectId: e.target.value })
                    }
                    className="input"
                  >
                    <option value="">General</option>
                    {subjects.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.icon} {s.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-medium">
                    Target Date
                  </label>
                  <input
                    type="date"
                    value={form.targetDate}
                    onChange={(e) =>
                      setForm({ ...form, targetDate: e.target.value })
                    }
                    className="input"
                  />
                </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setModalOpen(false)}
                className="flex-1 rounded-xl py-3 text-sm font-medium"
                style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
              >
                Cancel
              </button>
              <button
                onClick={save}
                disabled={saving || !form.title.trim()}
                className="btn-primary flex-1 py-3 text-sm disabled:opacity-50"
              >
                {saving ? "Saving..." : form.id ? "Save Changes" : "Create"}
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 10px;
          border: 1px solid var(--border-color);
          background: var(--bg-primary);
          color: var(--text-primary);
          padding: 0.6rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
