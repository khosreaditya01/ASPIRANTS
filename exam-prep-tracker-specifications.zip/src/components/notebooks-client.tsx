"use client";

import { useCallback, useEffect, useState } from "react";
import {
  Plus,
  Trash2,
  X,
  BookMarked,
  Check,
  ArrowLeft,
  NotebookPen,
} from "lucide-react";
import type { NotebookSummary, NotebookEntryRow } from "@/lib/types";

const NB_COLORS = ["#ef4444", "#f59e0b", "#6366f1", "#10b981", "#ec4899", "#06b6d4", "#8b5cf6", "#14b8a6"];
const NB_ICONS = ["📕", "📓", "📔", "⚠️", "🔥", "🎯", "🧠", "📝"];

export function NotebooksClient() {
  const [notebooks, setNotebooks] = useState<NotebookSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<NotebookSummary | null>(null);
  const [entries, setEntries] = useState<NotebookEntryRow[]>([]);
  const [entriesLoading, setEntriesLoading] = useState(false);

  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState("");
  const [color, setColor] = useState(NB_COLORS[0]);
  const [icon, setIcon] = useState(NB_ICONS[0]);
  const [saving, setSaving] = useState(false);

  const loadNotebooks = useCallback(() => {
    fetch("/api/notebooks")
      .then((r) => r.json())
      .then((d) => setNotebooks(Array.isArray(d) ? d : []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(loadNotebooks, [loadNotebooks]);

  const openNotebook = (nb: NotebookSummary) => {
    setActive(nb);
    setEntriesLoading(true);
    fetch(`/api/notebook-entries?notebookId=${nb.id}`)
      .then((r) => r.json())
      .then((d) => setEntries(Array.isArray(d) ? d : []))
      .finally(() => setEntriesLoading(false));
  };

  const createNotebook = async () => {
    if (!name.trim()) return;
    setSaving(true);
    await fetch("/api/notebooks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: name.trim(), color, icon }),
    });
    setSaving(false);
    setModalOpen(false);
    setName("");
    setColor(NB_COLORS[0]);
    setIcon(NB_ICONS[0]);
    setLoading(true);
    loadNotebooks();
  };

  const deleteNotebook = async (id: number) => {
    if (!confirm("Delete this notebook and all saved questions?")) return;
    await fetch(`/api/notebooks?id=${id}`, { method: "DELETE" });
    setNotebooks((prev) => prev.filter((n) => n.id !== id));
    if (active?.id === id) setActive(null);
  };

  const deleteEntry = async (entryId: number) => {
    await fetch(`/api/notebook-entries?id=${entryId}`, { method: "DELETE" });
    setEntries((prev) => prev.filter((e) => e.id !== entryId));
    setNotebooks((prev) =>
      prev.map((n) =>
        n.id === active?.id ? { ...n, entryCount: Math.max(0, n.entryCount - 1) } : n
      )
    );
  };

  // ---- Detail view ----
  if (active) {
    return (
      <div className="space-y-6">
        <button
          onClick={() => setActive(null)}
          className="flex items-center gap-1.5 text-sm font-medium"
          style={{ color: "var(--text-secondary)" }}
        >
          <ArrowLeft size={16} /> All Notebooks
        </button>

        <div className="flex items-center gap-3">
          <div
            className="grid h-12 w-12 place-items-center rounded-2xl text-2xl"
            style={{ background: active.color + "22" }}
          >
            {active.icon}
          </div>
          <div>
            <h1 className="text-2xl font-bold">{active.name}</h1>
            <p className="text-sm" style={{ color: "var(--text-muted)" }}>
              {entries.length} saved question{entries.length === 1 ? "" : "s"}
            </p>
          </div>
        </div>

        {entriesLoading ? (
          <div className="space-y-3">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="skeleton h-40 rounded-2xl" />
            ))}
          </div>
        ) : entries.length === 0 ? (
          <div className="surface flex flex-col items-center gap-3 rounded-2xl py-16 text-center">
            <div
              className="grid h-14 w-14 place-items-center rounded-2xl"
              style={{ background: "var(--accent-light)", color: "var(--accent)" }}
            >
              <NotebookPen size={26} />
            </div>
            <p className="text-lg font-semibold">No questions saved yet</p>
            <p className="max-w-sm text-sm" style={{ color: "var(--text-secondary)" }}>
              After a mock test, tap <strong>Add to Mistakes Notebook</strong> on any
              question in the review to save it here.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {entries.map((e, i) => (
              <div
                key={e.id}
                className={`surface animate-slide-up rounded-2xl p-5 stagger-${(i % 5) + 1}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <p className="font-medium">{e.questionText}</p>
                  <button
                    onClick={() => deleteEntry(e.id)}
                    className="grid h-8 w-8 shrink-0 place-items-center rounded-lg"
                    style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                  >
                    <Trash2 size={14} />
                  </button>
                </div>

                <div className="mt-3 space-y-2">
                  {e.options.map((opt, oi) => {
                    const isRight = oi === e.correctIndex;
                    const isChosen = oi === e.selectedIndex;
                    let bg = "var(--bg-hover)";
                    let bd = "transparent";
                    if (isRight) {
                      bg = "var(--success-light)";
                      bd = "var(--success)";
                    } else if (isChosen && !isRight) {
                      bg = "var(--danger-light)";
                      bd = "var(--danger)";
                    }
                    return (
                      <div
                        key={oi}
                        className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm"
                        style={{ background: bg, border: `1px solid ${bd}` }}
                      >
                        <span
                          className="grid h-5 w-5 shrink-0 place-items-center rounded-full text-xs font-bold"
                          style={{ background: "var(--bg-card)", color: "var(--text-muted)" }}
                        >
                          {String.fromCharCode(65 + oi)}
                        </span>
                        <span className="flex-1">{opt}</span>
                        {isRight && <Check size={15} style={{ color: "var(--success)" }} />}
                        {isChosen && !isRight && <X size={15} style={{ color: "var(--danger)" }} />}
                      </div>
                    );
                  })}
                </div>

                {e.explanation && (
                  <p
                    className="mt-3 rounded-lg px-3 py-2 text-sm"
                    style={{ background: "var(--accent-light)", color: "var(--text-secondary)" }}
                  >
                    <strong style={{ color: "var(--accent)" }}>Why: </strong>
                    {e.explanation}
                  </p>
                )}

                {e.sourceTestTitle && (
                  <p className="mt-3 text-xs" style={{ color: "var(--text-muted)" }}>
                    From: {e.sourceTestTitle}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  // ---- List view ----
  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold">Mistakes Notebooks</h1>
          <p className="mt-1 text-sm" style={{ color: "var(--text-secondary)" }}>
            Collect tricky questions from tests and revise them before exam day.
          </p>
        </div>
        <button
          onClick={() => setModalOpen(true)}
          className="btn-primary flex items-center gap-2 px-5 py-3 text-sm"
        >
          <Plus size={17} /> New Notebook
        </button>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="skeleton h-36 rounded-2xl" />
          ))}
        </div>
      ) : notebooks.length === 0 ? (
        <div className="surface flex flex-col items-center gap-3 rounded-2xl py-16 text-center">
          <div
            className="grid h-14 w-14 place-items-center rounded-2xl"
            style={{ background: "var(--accent-light)", color: "var(--accent)" }}
          >
            <BookMarked size={26} />
          </div>
          <p className="text-lg font-semibold">No notebooks yet</p>
          <p className="max-w-sm text-sm" style={{ color: "var(--text-secondary)" }}>
            Create a notebook, then add mistakes to it from any test review — or make
            one on the fly right from the test.
          </p>
          <button
            onClick={() => setModalOpen(true)}
            className="btn-primary mt-2 flex items-center gap-2 px-5 py-2.5 text-sm"
          >
            <Plus size={16} /> New Notebook
          </button>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {notebooks.map((nb, i) => (
            <div
              key={nb.id}
              onClick={() => openNotebook(nb)}
              className={`surface card-hover animate-slide-up cursor-pointer rounded-2xl p-5 stagger-${(i % 5) + 1}`}
            >
              <div className="flex items-start justify-between">
                <div
                  className="grid h-12 w-12 place-items-center rounded-2xl text-2xl"
                  style={{ background: nb.color + "22" }}
                >
                  {nb.icon}
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteNotebook(nb.id);
                  }}
                  className="grid h-8 w-8 place-items-center rounded-lg"
                  style={{ background: "var(--danger-light)", color: "var(--danger)" }}
                >
                  <Trash2 size={14} />
                </button>
              </div>
              <h3 className="mt-4 font-semibold">{nb.name}</h3>
              <p className="text-sm" style={{ color: "var(--text-muted)" }}>
                {nb.entryCount} question{nb.entryCount === 1 ? "" : "s"}
              </p>
            </div>
          ))}
        </div>
      )}

      {modalOpen && (
        <div
          className="modal-backdrop fixed inset-0 z-[60] flex items-center justify-center p-4"
          onClick={() => setModalOpen(false)}
        >
          <div
            className="surface animate-scale-in w-full max-w-md rounded-2xl p-6 shadow-lg"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-5 flex items-center justify-between">
              <h2 className="text-lg font-semibold">New Mistakes Notebook</h2>
              <button
                onClick={() => setModalOpen(false)}
                className="grid h-8 w-8 place-items-center rounded-lg"
                style={{ background: "var(--bg-hover)" }}
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-medium">Name</label>
                <input
                  autoFocus
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Physics Silly Mistakes"
                  className="input"
                  onKeyDown={(e) => e.key === "Enter" && createNotebook()}
                />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium">Icon</label>
                <div className="flex flex-wrap gap-2">
                  {NB_ICONS.map((ic) => (
                    <button
                      key={ic}
                      onClick={() => setIcon(ic)}
                      className="grid h-9 w-9 place-items-center rounded-lg text-lg"
                      style={{
                        background: icon === ic ? "var(--accent-light)" : "var(--bg-hover)",
                        outline: icon === ic ? "2px solid var(--accent)" : "none",
                      }}
                    >
                      {ic}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium">Color</label>
                <div className="flex flex-wrap gap-2">
                  {NB_COLORS.map((c) => (
                    <button
                      key={c}
                      onClick={() => setColor(c)}
                      className="h-8 w-8 rounded-full"
                      style={{
                        background: c,
                        transform: color === c ? "scale(1.15)" : "scale(1)",
                        outline: color === c ? "2px solid var(--text-primary)" : "none",
                        outlineOffset: 2,
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-6 flex gap-3">
              <button
                onClick={() => setModalOpen(false)}
                className="flex-1 rounded-xl py-3 text-sm font-medium"
                style={{ background: "var(--bg-hover)", color: "var(--text-secondary)" }}
              >
                Cancel
              </button>
              <button
                onClick={createNotebook}
                disabled={saving || !name.trim()}
                className="btn-primary flex-1 py-3 text-sm disabled:opacity-50"
              >
                {saving ? "Creating…" : "Create"}
              </button>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .input {
          width: 100%;
          border-radius: 10px;
          border: 1px solid var(--border-color);
          background: var(--bg-primary);
          color: var(--text-primary);
          padding: 0.6rem 0.75rem;
          font-size: 0.875rem;
        }
      `}</style>
    </div>
  );
}
