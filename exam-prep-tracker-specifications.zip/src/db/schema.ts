import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  date,
  jsonb,
  real,
} from "drizzle-orm/pg-core";

export const subjects = pgTable("subjects", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#6366f1"),
  icon: text("icon").notNull().default("📘"),
  totalTopics: integer("total_topics").notNull().default(0),
  completedTopics: integer("completed_topics").notNull().default(0),
  targetHours: integer("target_hours").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const studySessions = pgTable("study_sessions", {
  id: serial("id").primaryKey(),
  subjectId: integer("subject_id")
    .notNull()
    .references(() => subjects.id, { onDelete: "cascade" }),
  durationMinutes: integer("duration_minutes").notNull().default(0),
  notes: text("notes"),
  date: date("date").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const goals = pgTable("goals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  subjectId: integer("subject_id").references(() => subjects.id, {
    onDelete: "set null",
  }),
  targetDate: date("target_date"),
  completed: boolean("completed").notNull().default(false),
  priority: text("priority").notNull().default("medium"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const dailyLogs = pgTable("daily_logs", {
  id: serial("id").primaryKey(),
  date: date("date").notNull().unique(),
  totalMinutes: integer("total_minutes").notNull().default(0),
  sessionsCount: integer("sessions_count").notNull().default(0),
  mood: text("mood"),
  note: text("note"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Subject = typeof subjects.$inferSelect;
export type NewSubject = typeof subjects.$inferInsert;
export type StudySession = typeof studySessions.$inferSelect;
export type NewStudySession = typeof studySessions.$inferInsert;
export type Goal = typeof goals.$inferSelect;
export type NewGoal = typeof goals.$inferInsert;
export const doubts = pgTable("doubts", {
  id: serial("id").primaryKey(),
  prompt: text("prompt"),
  answer: text("answer").notNull(),
  subjectId: integer("subject_id").references(() => subjects.id, {
    onDelete: "set null",
  }),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type DailyLog = typeof dailyLogs.$inferSelect;
export type Doubt = typeof doubts.$inferSelect;
export type NewDoubt = typeof doubts.$inferInsert;

export const tests = pgTable("tests", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  subjectId: integer("subject_id").references(() => subjects.id, {
    onDelete: "set null",
  }),
  durationMinutes: integer("duration_minutes").notNull().default(30),
  marksPerQuestion: real("marks_per_question").notNull().default(1),
  negativeMarks: real("negative_marks").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const testQuestions = pgTable("test_questions", {
  id: serial("id").primaryKey(),
  testId: integer("test_id")
    .notNull()
    .references(() => tests.id, { onDelete: "cascade" }),
  questionText: text("question_text").notNull(),
  options: jsonb("options").notNull().$type<string[]>(),
  correctIndex: integer("correct_index").notNull().default(0),
  explanation: text("explanation"),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const testAttempts = pgTable("test_attempts", {
  id: serial("id").primaryKey(),
  testId: integer("test_id")
    .notNull()
    .references(() => tests.id, { onDelete: "cascade" }),
  score: real("score").notNull().default(0),
  totalMarks: real("total_marks").notNull().default(0),
  correctCount: integer("correct_count").notNull().default(0),
  wrongCount: integer("wrong_count").notNull().default(0),
  skippedCount: integer("skipped_count").notNull().default(0),
  timeTakenSeconds: integer("time_taken_seconds").notNull().default(0),
  answers: jsonb("answers").notNull().$type<Record<string, number>>(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Test = typeof tests.$inferSelect;
export type NewTest = typeof tests.$inferInsert;
export type TestQuestion = typeof testQuestions.$inferSelect;
export type NewTestQuestion = typeof testQuestions.$inferInsert;
export type TestAttempt = typeof testAttempts.$inferSelect;
export type NewTestAttempt = typeof testAttempts.$inferInsert;

export const notebooks = pgTable("notebooks", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#ef4444"),
  icon: text("icon").notNull().default("📕"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const notebookEntries = pgTable("notebook_entries", {
  id: serial("id").primaryKey(),
  notebookId: integer("notebook_id")
    .notNull()
    .references(() => notebooks.id, { onDelete: "cascade" }),
  questionText: text("question_text").notNull(),
  options: jsonb("options").notNull().$type<string[]>(),
  correctIndex: integer("correct_index").notNull().default(0),
  selectedIndex: integer("selected_index"),
  explanation: text("explanation"),
  note: text("note"),
  sourceTestId: integer("source_test_id").references(() => tests.id, {
    onDelete: "set null",
  }),
  sourceTestTitle: text("source_test_title"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Notebook = typeof notebooks.$inferSelect;
export type NewNotebook = typeof notebooks.$inferInsert;
export type NotebookEntry = typeof notebookEntries.$inferSelect;
export type NewNotebookEntry = typeof notebookEntries.$inferInsert;
