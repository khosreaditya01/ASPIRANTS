export interface Subject {
  id: number;
  name: string;
  color: string;
  icon: string;
  totalTopics: number;
  completedTopics: number;
  targetHours: number;
  createdAt: string;
}

export interface SessionRow {
  id: number;
  subjectId: number;
  durationMinutes: number;
  notes: string | null;
  date: string;
  createdAt: string;
  subjectName: string | null;
  subjectColor: string | null;
  subjectIcon: string | null;
}

export interface GoalRow {
  id: number;
  title: string;
  description: string | null;
  subjectId: number | null;
  targetDate: string | null;
  completed: boolean;
  priority: string;
  createdAt: string;
  subjectName: string | null;
  subjectColor: string | null;
  subjectIcon: string | null;
}

export interface Stats {
  totalMinutes: number;
  sessionCount: number;
  subjectCount: number;
  completedGoals: number;
  pendingGoals: number;
  totalGoals: number;
  streak: number;
  totalTopics: number;
  completedTopics: number;
  weekly: { date: string; label: string; minutes: number }[];
  recentSessions: {
    id: number;
    durationMinutes: number;
    notes: string | null;
    date: string;
    subjectName: string | null;
    subjectColor: string | null;
    subjectIcon: string | null;
  }[];
  upcomingGoals: {
    id: number;
    title: string;
    targetDate: string | null;
    priority: string;
    subjectName: string | null;
    subjectColor: string | null;
  }[];
  perSubject: {
    subjectId: number;
    name: string | null;
    color: string | null;
    icon: string | null;
    totalMinutes: number;
  }[];
  subjects: Subject[];
}

export interface DoubtRow {
  id: number;
  prompt: string | null;
  answer: string;
  subjectId: number | null;
  createdAt: string;
  subjectName: string | null;
  subjectColor: string | null;
  subjectIcon: string | null;
}

export interface TestSummary {
  id: number;
  title: string;
  description: string | null;
  subjectId: number | null;
  durationMinutes: number;
  marksPerQuestion: number;
  negativeMarks: number;
  createdAt: string;
  subjectName: string | null;
  subjectColor: string | null;
  subjectIcon: string | null;
  questionCount: number;
  attemptCount: number;
  bestScore: number | null;
}

// Question as sent to the test runner (no correct answer exposed).
export interface RunnerQuestion {
  id: number;
  questionText: string;
  options: string[];
  position: number;
}

// Question with the answer key, for editing/review.
export interface FullQuestion extends RunnerQuestion {
  correctIndex: number;
  explanation: string | null;
}

export interface TestDetail {
  id: number;
  title: string;
  description: string | null;
  subjectId: number | null;
  durationMinutes: number;
  marksPerQuestion: number;
  negativeMarks: number;
  subjectName: string | null;
  questions: RunnerQuestion[];
}

export interface AttemptResult {
  score: number;
  totalMarks: number;
  correctCount: number;
  wrongCount: number;
  skippedCount: number;
  timeTakenSeconds: number;
  review: {
    id: number;
    questionText: string;
    options: string[];
    correctIndex: number;
    selectedIndex: number | null;
    explanation: string | null;
  }[];
}

export interface NotebookSummary {
  id: number;
  name: string;
  color: string;
  icon: string;
  createdAt: string;
  entryCount: number;
}

export interface NotebookEntryRow {
  id: number;
  notebookId: number;
  questionText: string;
  options: string[];
  correctIndex: number;
  selectedIndex: number | null;
  explanation: string | null;
  note: string | null;
  sourceTestId: number | null;
  sourceTestTitle: string | null;
  createdAt: string;
}

export function formatHours(minutes: number): string {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  if (h === 0) return `${m}m`;
  if (m === 0) return `${h}h`;
  return `${h}h ${m}m`;
}
