import { db } from "@/db";
import { goals, subjects } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: goals.id,
        title: goals.title,
        description: goals.description,
        subjectId: goals.subjectId,
        targetDate: goals.targetDate,
        completed: goals.completed,
        priority: goals.priority,
        createdAt: goals.createdAt,
        subjectName: subjects.name,
        subjectColor: subjects.color,
        subjectIcon: subjects.icon,
      })
      .from(goals)
      .leftJoin(subjects, eq(goals.subjectId, subjects.id))
      .orderBy(desc(goals.createdAt));
    return Response.json(rows);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch goals" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body.title) {
      return Response.json({ error: "title is required" }, { status: 400 });
    }
    const [row] = await db
      .insert(goals)
      .values({
        title: body.title,
        description: body.description ?? null,
        subjectId: body.subjectId ? Number(body.subjectId) : null,
        targetDate: body.targetDate || null,
        priority: body.priority ?? "medium",
        completed: Boolean(body.completed),
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to create goal" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    if (!body.id) return Response.json({ error: "id is required" }, { status: 400 });

    const updates: Record<string, unknown> = {};
    if (body.title !== undefined) updates.title = body.title;
    if (body.description !== undefined) updates.description = body.description;
    if (body.subjectId !== undefined)
      updates.subjectId = body.subjectId ? Number(body.subjectId) : null;
    if (body.targetDate !== undefined) updates.targetDate = body.targetDate || null;
    if (body.priority !== undefined) updates.priority = body.priority;
    if (body.completed !== undefined) updates.completed = Boolean(body.completed);

    const [row] = await db
      .update(goals)
      .set(updates)
      .where(eq(goals.id, Number(body.id)))
      .returning();
    return Response.json(row);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to update goal" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "id is required" }, { status: 400 });
    await db.delete(goals).where(eq(goals.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to delete goal" }, { status: 500 });
  }
}
