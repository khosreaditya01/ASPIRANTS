import { db } from "@/db";
import { studySessions, dailyLogs, subjects } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: studySessions.id,
        subjectId: studySessions.subjectId,
        durationMinutes: studySessions.durationMinutes,
        notes: studySessions.notes,
        date: studySessions.date,
        createdAt: studySessions.createdAt,
        subjectName: subjects.name,
        subjectColor: subjects.color,
        subjectIcon: subjects.icon,
      })
      .from(studySessions)
      .leftJoin(subjects, eq(studySessions.subjectId, subjects.id))
      .orderBy(desc(studySessions.date), desc(studySessions.createdAt));
    return Response.json(rows);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch sessions" }, { status: 500 });
  }
}

async function refreshDailyLog(dateStr: string) {
  const [agg] = await db
    .select({
      total: sql<number>`coalesce(sum(${studySessions.durationMinutes}), 0)`,
      count: sql<number>`count(*)`,
    })
    .from(studySessions)
    .where(eq(studySessions.date, dateStr));

  const total = Number(agg?.total ?? 0);
  const count = Number(agg?.count ?? 0);

  if (count === 0) {
    await db.delete(dailyLogs).where(eq(dailyLogs.date, dateStr));
    return;
  }

  const existing = await db
    .select()
    .from(dailyLogs)
    .where(eq(dailyLogs.date, dateStr));

  if (existing.length > 0) {
    await db
      .update(dailyLogs)
      .set({ totalMinutes: total, sessionsCount: count })
      .where(eq(dailyLogs.date, dateStr));
  } else {
    await db
      .insert(dailyLogs)
      .values({ date: dateStr, totalMinutes: total, sessionsCount: count });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body.subjectId) {
      return Response.json({ error: "subjectId is required" }, { status: 400 });
    }
    const dateStr = body.date || new Date().toISOString().slice(0, 10);
    const [row] = await db
      .insert(studySessions)
      .values({
        subjectId: Number(body.subjectId),
        durationMinutes: Number(body.durationMinutes) || 0,
        notes: body.notes ?? null,
        date: dateStr,
      })
      .returning();
    await refreshDailyLog(dateStr);
    return Response.json(row, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to create session" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "id is required" }, { status: 400 });
    const [deleted] = await db
      .delete(studySessions)
      .where(eq(studySessions.id, Number(id)))
      .returning();
    if (deleted) await refreshDailyLog(deleted.date);
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to delete session" }, { status: 500 });
  }
}
