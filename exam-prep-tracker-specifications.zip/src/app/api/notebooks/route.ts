import { db } from "@/db";
import { notebooks, notebookEntries } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: notebooks.id,
        name: notebooks.name,
        color: notebooks.color,
        icon: notebooks.icon,
        createdAt: notebooks.createdAt,
        entryCount: sql<number>`(select count(*) from ${notebookEntries} where ${notebookEntries.notebookId} = ${notebooks.id})`,
      })
      .from(notebooks)
      .orderBy(desc(notebooks.createdAt));

    return Response.json(
      rows.map((r) => ({ ...r, entryCount: Number(r.entryCount) }))
    );
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch notebooks" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body.name || typeof body.name !== "string" || !body.name.trim()) {
      return Response.json({ error: "Notebook name is required" }, { status: 400 });
    }
    const [row] = await db
      .insert(notebooks)
      .values({
        name: body.name.trim(),
        color: body.color ?? "#ef4444",
        icon: body.icon ?? "📕",
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to create notebook" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    if (!body.id) return Response.json({ error: "id is required" }, { status: 400 });
    const [row] = await db
      .update(notebooks)
      .set({
        name: body.name,
        color: body.color,
        icon: body.icon,
      })
      .where(eq(notebooks.id, Number(body.id)))
      .returning();
    return Response.json(row);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to update notebook" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "id is required" }, { status: 400 });
    await db.delete(notebooks).where(eq(notebooks.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to delete notebook" }, { status: 500 });
  }
}
