import { db } from "@/db";
import { notebookEntries, notebooks } from "@/db/schema";
import { eq, desc, and } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const notebookId = searchParams.get("notebookId");
    const base = db
      .select()
      .from(notebookEntries)
      .orderBy(desc(notebookEntries.createdAt));
    const rows = notebookId
      ? await base.where(eq(notebookEntries.notebookId, Number(notebookId)))
      : await base;
    return Response.json(rows);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch entries" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const notebookId = Number(body.notebookId);
    if (!notebookId) {
      return Response.json({ error: "notebookId is required" }, { status: 400 });
    }
    // Ensure the notebook exists.
    const [nb] = await db
      .select({ id: notebooks.id })
      .from(notebooks)
      .where(eq(notebooks.id, notebookId));
    if (!nb) {
      return Response.json({ error: "Notebook not found" }, { status: 404 });
    }
    if (!body.questionText || !Array.isArray(body.options)) {
      return Response.json(
        { error: "Question text and options are required" },
        { status: 400 }
      );
    }

    // Avoid exact duplicates in the same notebook.
    const existing = await db
      .select({ id: notebookEntries.id })
      .from(notebookEntries)
      .where(
        and(
          eq(notebookEntries.notebookId, notebookId),
          eq(notebookEntries.questionText, String(body.questionText))
        )
      );
    if (existing.length > 0) {
      return Response.json(
        { ok: true, duplicate: true, id: existing[0].id },
        { status: 200 }
      );
    }

    const [row] = await db
      .insert(notebookEntries)
      .values({
        notebookId,
        questionText: String(body.questionText),
        options: (body.options as unknown[]).map((o) => String(o)),
        correctIndex: Number(body.correctIndex) || 0,
        selectedIndex:
          body.selectedIndex === null || body.selectedIndex === undefined
            ? null
            : Number(body.selectedIndex),
        explanation: body.explanation ?? null,
        note: body.note ?? null,
        sourceTestId: body.sourceTestId ? Number(body.sourceTestId) : null,
        sourceTestTitle: body.sourceTestTitle ?? null,
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to add entry" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "id is required" }, { status: 400 });
    await db.delete(notebookEntries).where(eq(notebookEntries.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to delete entry" }, { status: 500 });
  }
}
