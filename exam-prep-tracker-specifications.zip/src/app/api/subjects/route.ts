import { db } from "@/db";
import { subjects } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db.select().from(subjects).orderBy(desc(subjects.createdAt));
    return Response.json(rows);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch subjects" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body.name || typeof body.name !== "string") {
      return Response.json({ error: "Name is required" }, { status: 400 });
    }
    const [row] = await db
      .insert(subjects)
      .values({
        name: body.name,
        color: body.color ?? "#6366f1",
        icon: body.icon ?? "📘",
        totalTopics: Number(body.totalTopics) || 0,
        completedTopics: Number(body.completedTopics) || 0,
        targetHours: Number(body.targetHours) || 0,
      })
      .returning();
    return Response.json(row, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to create subject" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    if (!body.id) {
      return Response.json({ error: "id is required" }, { status: 400 });
    }
    const [row] = await db
      .update(subjects)
      .set({
        name: body.name,
        color: body.color,
        icon: body.icon,
        totalTopics: Number(body.totalTopics) || 0,
        completedTopics: Number(body.completedTopics) || 0,
        targetHours: Number(body.targetHours) || 0,
      })
      .where(eq(subjects.id, Number(body.id)))
      .returning();
    return Response.json(row);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to update subject" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "id is required" }, { status: 400 });
    await db.delete(subjects).where(eq(subjects.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to delete subject" }, { status: 500 });
  }
}
