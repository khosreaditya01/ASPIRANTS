import { db } from "@/db";
import { studySessions, subjects, goals, dailyLogs } from "@/db/schema";
import { eq, desc, sql, gte } from "drizzle-orm";

export const dynamic = "force-dynamic";

function toDateStr(d: Date) {
  return d.toISOString().slice(0, 10);
}

function computeStreak(dates: Set<string>): number {
  let streak = 0;
  const cursor = new Date();
  // Allow streak to count from today or yesterday.
  if (!dates.has(toDateStr(cursor))) {
    cursor.setDate(cursor.getDate() - 1);
    if (!dates.has(toDateStr(cursor))) return 0;
  }
  while (dates.has(toDateStr(cursor))) {
    streak++;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

export async function GET() {
  try {
    // Totals
    const [sessionAgg] = await db
      .select({
        totalMinutes: sql<number>`coalesce(sum(${studySessions.durationMinutes}), 0)`,
        sessionCount: sql<number>`count(*)`,
      })
      .from(studySessions);

    const subjectRows = await db.select().from(subjects);
    const goalRows = await db.select().from(goals);

    const completedGoals = goalRows.filter((g) => g.completed).length;
    const pendingGoals = goalRows.length - completedGoals;

    // Streak from daily logs
    const logs = await db.select({ date: dailyLogs.date }).from(dailyLogs);
    const streak = computeStreak(new Set(logs.map((l) => l.date)));

    // Weekly chart: last 7 days
    const today = new Date();
    const days: { date: string; label: string; minutes: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(today);
      d.setDate(d.getDate() - i);
      days.push({
        date: toDateStr(d),
        label: d.toLocaleDateString("en-US", { weekday: "short" }),
        minutes: 0,
      });
    }
    const weekStart = days[0].date;
    const weekSessions = await db
      .select({
        date: studySessions.date,
        total: sql<number>`coalesce(sum(${studySessions.durationMinutes}), 0)`,
      })
      .from(studySessions)
      .where(gte(studySessions.date, weekStart))
      .groupBy(studySessions.date);

    const weekMap = new Map(weekSessions.map((w) => [w.date, Number(w.total)]));
    for (const day of days) {
      day.minutes = weekMap.get(day.date) ?? 0;
    }

    // Recent sessions
    const recentSessions = await db
      .select({
        id: studySessions.id,
        durationMinutes: studySessions.durationMinutes,
        notes: studySessions.notes,
        date: studySessions.date,
        subjectName: subjects.name,
        subjectColor: subjects.color,
        subjectIcon: subjects.icon,
      })
      .from(studySessions)
      .leftJoin(subjects, eq(studySessions.subjectId, subjects.id))
      .orderBy(desc(studySessions.date), desc(studySessions.createdAt))
      .limit(5);

    // Upcoming pending goals
    const upcomingGoals = await db
      .select({
        id: goals.id,
        title: goals.title,
        targetDate: goals.targetDate,
        priority: goals.priority,
        subjectName: subjects.name,
        subjectColor: subjects.color,
      })
      .from(goals)
      .leftJoin(subjects, eq(goals.subjectId, subjects.id))
      .where(eq(goals.completed, false))
      .orderBy(goals.targetDate)
      .limit(5);

    // Hours per subject
    const perSubject = await db
      .select({
        subjectId: studySessions.subjectId,
        name: subjects.name,
        color: subjects.color,
        icon: subjects.icon,
        totalMinutes: sql<number>`coalesce(sum(${studySessions.durationMinutes}), 0)`,
      })
      .from(studySessions)
      .leftJoin(subjects, eq(studySessions.subjectId, subjects.id))
      .groupBy(
        studySessions.subjectId,
        subjects.name,
        subjects.color,
        subjects.icon
      );

    const totalTopics = subjectRows.reduce((a, s) => a + s.totalTopics, 0);
    const completedTopics = subjectRows.reduce(
      (a, s) => a + s.completedTopics,
      0
    );

    return Response.json({
      totalMinutes: Number(sessionAgg?.totalMinutes ?? 0),
      sessionCount: Number(sessionAgg?.sessionCount ?? 0),
      subjectCount: subjectRows.length,
      completedGoals,
      pendingGoals,
      totalGoals: goalRows.length,
      streak,
      totalTopics,
      completedTopics,
      weekly: days,
      recentSessions,
      upcomingGoals,
      perSubject: perSubject.map((p) => ({
        ...p,
        totalMinutes: Number(p.totalMinutes),
      })),
      subjects: subjectRows,
    });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch stats" }, { status: 500 });
  }
}
