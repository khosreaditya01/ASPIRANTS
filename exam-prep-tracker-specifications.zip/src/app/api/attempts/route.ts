import { db } from "@/db";
import { tests, testQuestions, testAttempts } from "@/db/schema";
import { eq, asc, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const testId = searchParams.get("testId");
    const base = db
      .select({
        id: testAttempts.id,
        testId: testAttempts.testId,
        score: testAttempts.score,
        totalMarks: testAttempts.totalMarks,
        correctCount: testAttempts.correctCount,
        wrongCount: testAttempts.wrongCount,
        skippedCount: testAttempts.skippedCount,
        timeTakenSeconds: testAttempts.timeTakenSeconds,
        createdAt: testAttempts.createdAt,
        testTitle: tests.title,
      })
      .from(testAttempts)
      .leftJoin(tests, eq(testAttempts.testId, tests.id))
      .orderBy(desc(testAttempts.createdAt));

    const rows = testId
      ? await base.where(eq(testAttempts.testId, Number(testId)))
      : await base;

    return Response.json(rows);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch attempts" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const testId = Number(body.testId);
    const answers: Record<string, number> = body.answers ?? {};
    const timeTaken = Math.max(0, Number(body.timeTakenSeconds) || 0);

    if (!testId) {
      return Response.json({ error: "testId is required" }, { status: 400 });
    }

    const [test] = await db.select().from(tests).where(eq(tests.id, testId));
    if (!test) {
      return Response.json({ error: "Test not found" }, { status: 404 });
    }

    const qs = await db
      .select()
      .from(testQuestions)
      .where(eq(testQuestions.testId, testId))
      .orderBy(asc(testQuestions.position));

    let correct = 0;
    let wrong = 0;
    let skipped = 0;
    let score = 0;

    const review = qs.map((q) => {
      const sel = answers[String(q.id)];
      const selectedIndex =
        typeof sel === "number" && sel >= 0 ? sel : null;
      if (selectedIndex === null) {
        skipped++;
      } else if (selectedIndex === q.correctIndex) {
        correct++;
        score += test.marksPerQuestion;
      } else {
        wrong++;
        score -= test.negativeMarks;
      }
      return {
        id: q.id,
        questionText: q.questionText,
        options: q.options,
        correctIndex: q.correctIndex,
        selectedIndex,
        explanation: q.explanation,
      };
    });

    const totalMarks = qs.length * test.marksPerQuestion;
    score = Math.round(score * 100) / 100;

    await db.insert(testAttempts).values({
      testId,
      score,
      totalMarks,
      correctCount: correct,
      wrongCount: wrong,
      skippedCount: skipped,
      timeTakenSeconds: timeTaken,
      answers,
    });

    return Response.json({
      score,
      totalMarks,
      correctCount: correct,
      wrongCount: wrong,
      skippedCount: skipped,
      timeTakenSeconds: timeTaken,
      review,
    });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to submit attempt" }, { status: 500 });
  }
}
