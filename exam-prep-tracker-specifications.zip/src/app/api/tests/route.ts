import { db } from "@/db";
import { tests, testQuestions, testAttempts, subjects } from "@/db/schema";
import { eq, desc, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const rows = await db
      .select({
        id: tests.id,
        title: tests.title,
        description: tests.description,
        subjectId: tests.subjectId,
        durationMinutes: tests.durationMinutes,
        marksPerQuestion: tests.marksPerQuestion,
        negativeMarks: tests.negativeMarks,
        createdAt: tests.createdAt,
        subjectName: subjects.name,
        subjectColor: subjects.color,
        subjectIcon: subjects.icon,
        questionCount: sql<number>`(select count(*) from ${testQuestions} where ${testQuestions.testId} = ${tests.id})`,
        attemptCount: sql<number>`(select count(*) from ${testAttempts} where ${testAttempts.testId} = ${tests.id})`,
        bestScore: sql<number | null>`(select max(${testAttempts.score}) from ${testAttempts} where ${testAttempts.testId} = ${tests.id})`,
      })
      .from(tests)
      .leftJoin(subjects, eq(tests.subjectId, subjects.id))
      .orderBy(desc(tests.createdAt));

    return Response.json(
      rows.map((r) => ({
        ...r,
        questionCount: Number(r.questionCount),
        attemptCount: Number(r.attemptCount),
        bestScore: r.bestScore === null ? null : Number(r.bestScore),
      }))
    );
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch tests" }, { status: 500 });
  }
}

interface QuestionInput {
  questionText: string;
  options: string[];
  correctIndex: number;
  explanation?: string | null;
}

function validateQuestions(input: unknown): QuestionInput[] | null {
  if (!Array.isArray(input) || input.length === 0) return null;
  const out: QuestionInput[] = [];
  for (const q of input) {
    if (!q || typeof q.questionText !== "string" || !q.questionText.trim())
      return null;
    const opts = Array.isArray(q.options)
      ? q.options.map((o: unknown) => String(o ?? "").trim()).filter(Boolean)
      : [];
    if (opts.length < 2) return null;
    const ci = Number(q.correctIndex);
    if (!Number.isInteger(ci) || ci < 0 || ci >= opts.length) return null;
    out.push({
      questionText: q.questionText.trim(),
      options: opts,
      correctIndex: ci,
      explanation:
        typeof q.explanation === "string" && q.explanation.trim()
          ? q.explanation.trim()
          : null,
    });
  }
  return out;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    if (!body.title || typeof body.title !== "string" || !body.title.trim()) {
      return Response.json({ error: "Title is required" }, { status: 400 });
    }
    const questions = validateQuestions(body.questions);
    if (!questions) {
      return Response.json(
        { error: "Add at least one valid question with 2+ options and a correct answer." },
        { status: 400 }
      );
    }

    const [test] = await db
      .insert(tests)
      .values({
        title: body.title.trim(),
        description: body.description?.trim() || null,
        subjectId: body.subjectId ? Number(body.subjectId) : null,
        durationMinutes: Math.max(1, Number(body.durationMinutes) || 30),
        marksPerQuestion: Number(body.marksPerQuestion) || 1,
        negativeMarks: Math.max(0, Number(body.negativeMarks) || 0),
      })
      .returning();

    await db.insert(testQuestions).values(
      questions.map((q, i) => ({
        testId: test.id,
        questionText: q.questionText,
        options: q.options,
        correctIndex: q.correctIndex,
        explanation: q.explanation,
        position: i,
      }))
    );

    return Response.json(test, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to create test" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "id is required" }, { status: 400 });
    await db.delete(tests).where(eq(tests.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to delete test" }, { status: 500 });
  }
}
