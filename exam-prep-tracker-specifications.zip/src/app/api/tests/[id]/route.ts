import { db } from "@/db";
import { tests, testQuestions, subjects } from "@/db/schema";
import { eq, asc } from "drizzle-orm";

export const dynamic = "force-dynamic";

interface QuestionInput {
  questionText: string;
  options: string[];
  correctIndex: number;
  explanation?: string | null;
}

function validateQuestions(input: unknown): QuestionInput[] | null {
  if (!Array.isArray(input) || input.length === 0) return null;
  const out: QuestionInput[] = [];
  for (const q of input) {
    if (!q || typeof q.questionText !== "string" || !q.questionText.trim())
      return null;
    const opts = Array.isArray(q.options)
      ? q.options.map((o: unknown) => String(o ?? "").trim()).filter(Boolean)
      : [];
    if (opts.length < 2) return null;
    const ci = Number(q.correctIndex);
    if (!Number.isInteger(ci) || ci < 0 || ci >= opts.length) return null;
    out.push({
      questionText: q.questionText.trim(),
      options: opts,
      correctIndex: ci,
      explanation:
        typeof q.explanation === "string" && q.explanation.trim()
          ? q.explanation.trim()
          : null,
    });
  }
  return out;
}

export async function GET(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const testId = Number(id);
    const { searchParams } = new URL(req.url);
    const withAnswers = searchParams.get("withAnswers") === "1";

    const [test] = await db
      .select({
        id: tests.id,
        title: tests.title,
        description: tests.description,
        subjectId: tests.subjectId,
        durationMinutes: tests.durationMinutes,
        marksPerQuestion: tests.marksPerQuestion,
        negativeMarks: tests.negativeMarks,
        subjectName: subjects.name,
      })
      .from(tests)
      .leftJoin(subjects, eq(tests.subjectId, subjects.id))
      .where(eq(tests.id, testId));

    if (!test) {
      return Response.json({ error: "Test not found" }, { status: 404 });
    }

    const qs = await db
      .select()
      .from(testQuestions)
      .where(eq(testQuestions.testId, testId))
      .orderBy(asc(testQuestions.position));

    const questions = qs.map((q) => ({
      id: q.id,
      questionText: q.questionText,
      options: q.options,
      position: q.position,
      ...(withAnswers
        ? { correctIndex: q.correctIndex, explanation: q.explanation }
        : {}),
    }));

    return Response.json({ ...test, questions });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch test" }, { status: 500 });
  }
}

export async function PUT(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const testId = Number(id);
    const body = await req.json();

    if (!body.title || typeof body.title !== "string" || !body.title.trim()) {
      return Response.json({ error: "Title is required" }, { status: 400 });
    }
    const questions = validateQuestions(body.questions);
    if (!questions) {
      return Response.json(
        { error: "Add at least one valid question with 2+ options and a correct answer." },
        { status: 400 }
      );
    }

    await db
      .update(tests)
      .set({
        title: body.title.trim(),
        description: body.description?.trim() || null,
        subjectId: body.subjectId ? Number(body.subjectId) : null,
        durationMinutes: Math.max(1, Number(body.durationMinutes) || 30),
        marksPerQuestion: Number(body.marksPerQuestion) || 1,
        negativeMarks: Math.max(0, Number(body.negativeMarks) || 0),
      })
      .where(eq(tests.id, testId));

    // Replace all questions with the new set.
    await db.delete(testQuestions).where(eq(testQuestions.testId, testId));
    await db.insert(testQuestions).values(
      questions.map((q, i) => ({
        testId,
        questionText: q.questionText,
        options: q.options,
        correctIndex: q.correctIndex,
        explanation: q.explanation,
        position: i,
      }))
    );

    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to update test" }, { status: 500 });
  }
}
