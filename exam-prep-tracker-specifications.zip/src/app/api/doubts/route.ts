import { db } from "@/db";
import { doubts, subjects } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

const SYSTEM_PROMPT = `You are "Aspirants AI", an expert tutor that helps students preparing for competitive exams.
The student uploads a photo of a question, problem, or their handwritten doubt.

Your job:
1. First, read and restate the question briefly so the student knows you understood it.
2. Solve it step by step with clear, numbered reasoning.
3. Highlight the key concept/formula being tested.
4. End with a clearly marked **Final Answer**.

Formatting rules:
- Use clean Markdown (headings, bold, numbered/bulleted lists).
- For math, prefer plain readable notation and Unicode symbols (×, ÷, √, ², ³, π, ≤, ≥, →). Avoid heavy LaTeX.
- Be concise but complete. If the image is unreadable, say so and ask for a clearer photo.
- If it is a multiple-choice question, state which option is correct and why.`;

export async function GET() {
  try {
    const rows = await db
      .select({
        id: doubts.id,
        prompt: doubts.prompt,
        answer: doubts.answer,
        subjectId: doubts.subjectId,
        createdAt: doubts.createdAt,
        subjectName: subjects.name,
        subjectColor: subjects.color,
        subjectIcon: subjects.icon,
      })
      .from(doubts)
      .leftJoin(subjects, eq(doubts.subjectId, subjects.id))
      .orderBy(desc(doubts.createdAt))
      .limit(50);
    return Response.json(rows);
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to fetch doubts" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return Response.json(
        {
          error:
            "AI is not configured. Add a GEMINI_API_KEY secret to enable the doubt solver.",
          code: "NO_KEY",
        },
        { status: 503 }
      );
    }

    const body = await req.json();
    const { image, prompt, subjectId } = body as {
      image?: string;
      prompt?: string;
      subjectId?: string | number | null;
    };

    if (!image || typeof image !== "string" || !image.startsWith("data:")) {
      return Response.json(
        { error: "A valid image is required." },
        { status: 400 }
      );
    }

    // Parse the data URL into mime type + base64 payload for Gemini.
    const match = image.match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
    if (!match) {
      return Response.json(
        { error: "Unsupported image format. Please upload a JPG or PNG." },
        { status: 400 }
      );
    }
    const mimeType = match[1];
    const base64Data = match[2];

    const userText =
      prompt && prompt.trim().length > 0
        ? `The student adds this note: "${prompt.trim()}". Now solve the question in the image.`
        : "Solve the question shown in this image.";

    const model = "gemini-2.5-flash";
    const aiRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          systemInstruction: {
            parts: [{ text: SYSTEM_PROMPT }],
          },
          contents: [
            {
              role: "user",
              parts: [
                { text: userText },
                { inlineData: { mimeType, data: base64Data } },
              ],
            },
          ],
          generationConfig: {
            temperature: 0.2,
            maxOutputTokens: 2048,
          },
        }),
      }
    );

    if (!aiRes.ok) {
      const errText = await aiRes.text();
      console.error("Gemini error:", aiRes.status, errText);
      if (aiRes.status === 429) {
        return Response.json(
          {
            error:
              "AI quota exceeded for now. Your Gemini key hit its rate/usage limit — wait a moment and try again, or check your plan & billing.",
            code: "QUOTA",
          },
          { status: 429 }
        );
      }
      return Response.json(
        { error: "The AI service returned an error. Please try again." },
        { status: 502 }
      );
    }

    const data = await aiRes.json();
    const answer: string =
      data?.candidates?.[0]?.content?.parts
        ?.map((p: { text?: string }) => p.text ?? "")
        .join("")
        .trim() ||
      "Sorry, I couldn't generate a solution. Please try a clearer image.";

    const [saved] = await db
      .insert(doubts)
      .values({
        prompt: prompt?.trim() || null,
        answer,
        subjectId: subjectId ? Number(subjectId) : null,
      })
      .returning();

    return Response.json({ answer, id: saved.id }, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to solve the doubt." }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return Response.json({ error: "id is required" }, { status: 400 });
    await db.delete(doubts).where(eq(doubts.id, Number(id)));
    return Response.json({ ok: true });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "Failed to delete doubt" }, { status: 500 });
  }
}
