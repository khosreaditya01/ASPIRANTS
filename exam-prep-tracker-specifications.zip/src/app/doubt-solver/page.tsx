import { DoubtSolverClient } from "@/components/doubt-solver-client";

export default function DoubtSolverPage() {
  return <DoubtSolverClient />;
}
