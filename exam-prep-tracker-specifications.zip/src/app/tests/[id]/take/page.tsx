import { TestRunnerClient } from "@/components/test-runner-client";

export default async function TakeTestPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  return <TestRunnerClient testId={Number(id)} />;
}
