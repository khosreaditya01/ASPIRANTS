import { SubjectsClient } from "@/components/subjects-client";

export default function SubjectsPage() {
  return <SubjectsClient />;
}
