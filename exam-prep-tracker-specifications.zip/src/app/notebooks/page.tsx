import { NotebooksClient } from "@/components/notebooks-client";

export default function NotebooksPage() {
  return <NotebooksClient />;
}
